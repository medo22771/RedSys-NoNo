package com.yelloco.redsys_testing;


import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import es.redsys.paysys.ConnectionPinPad.RedCLSConnectionPinPadWifi;
import es.redsys.paysys.Operative.DTO.RedCLSConfigurationPinPadData;
import es.redsys.paysys.Operative.Managers.RedCLSDccSelectionData;
import es.redsys.paysys.Operative.Managers.RedCLSDeferPaymentData;
import es.redsys.paysys.Operative.RedCLSPinPadInterface;


public class RedsysClient {
    MainActivity activity;
    RedCLSConnectionPinPadWifi pinpadWifi;
    String response;

    private class RedsysDummyInterface implements RedCLSPinPadInterface {
        MainActivity activity;

        public RedsysDummyInterface(MainActivity activity) {
            this.activity = activity;
        }

        public Context getContext() {
            return activity.getApplicationContext();
        }

        public void conexionPinPadRealizada() {
            // do nothing here
        }

        public void pinPadNoEncontrado() {
            // do nothing here
        }

        public void actualizacionEstadoOperacion(String var1) {
            // do nothing here
        }

        public String seleccionMonedaPagoDCC(RedCLSDccSelectionData var1) {
            // do nothing here
            return "";
        }

        public String selectionDeferPayment(RedCLSDeferPaymentData var1) {
            // do nothing here
            return "";
        }
    }

    public RedsysClient(MainActivity activity) {
        this.activity = activity;

        RedCLSConfigurationPinPadData pinPadData = new RedCLSConfigurationPinPadData(RedCLSConfigurationPinPadData.WIFI_CONNECTION);
        RedCLSPinPadInterface pinpadInterface = new RedsysDummyInterface(activity);
        pinpadWifi = new RedCLSConnectionPinPadWifi(pinpadInterface, pinPadData);
    }

    public void connect(String addr, int port) {
        RedCLSConfigurationPinPadData pinPadData = pinpadWifi.getConfigurationPinPad();
        if (pinpadWifi.isDeviceConnected()) {
            pinpadWifi.closeConnection();
        }
        pinPadData.setAddrDestination(addr);
        pinPadData.setDestPort(port);

        pinpadWifi.connectWithDevice();
    }

    public void disconnect() {
        pinpadWifi.closeConnection();
    }

    public void send(byte[] data) {
        final byte[] message = data;
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d("Response", "run: rr");
                    pinpadWifi.sendMessage(message);
                   response = pinpadWifi.waitResponseInString();
                    Log.d("Response", "run: Response" +response);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    response = "Exception: " + ex.toString();
                    Log.d("Response", "run: Response"+response);
                }
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ((TextView) activity.findViewById(R.id.output)).append("\nClient:" + response);
                    }
                });
            }
        });
    }
}
