package com.yelloco.redsys_testing;

import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;

public class DummyClient extends Thread {
    String addr;
    int port;
    MainActivity activity;
    Socket socket = null;
    String response;

    DummyClient(MainActivity activity) {
        this.activity = activity;
    }

    public void connect(String addr, int port) {
        this.addr = addr;
        this.port = port;
    }

    public void disconnect() {
        if (socket != null) {
            try {
                socket.close();
            } catch (IOException ex) {
                // TODO Auto-generated catch block
                throw new RuntimeException("Can't disconnect from server", ex);
            }
        }
    }

    @Override
    public void run() {
        response = "";

        try {
            if (socket == null || socket.isClosed()) {
                socket = new Socket(addr, port);
            }

            PrintStream printStream = new PrintStream(socket.getOutputStream(), true);
            printStream.println("Hello");
            printStream.flush();

            byte[] buffer = new byte[1024];
            int bytesRead;
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(
                    1024);
            InputStream inputStream = socket.getInputStream();

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                byteArrayOutputStream.write(buffer, 0, bytesRead);
                response += byteArrayOutputStream.toString("UTF-8");
                break;
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            response = "IOException: " + e.toString();
        }

        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ((TextView) activity.findViewById(R.id.output)).append("\nClient:" + response);
            }
        });
    }
}
