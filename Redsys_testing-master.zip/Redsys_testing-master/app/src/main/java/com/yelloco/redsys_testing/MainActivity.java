package com.yelloco.redsys_testing;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {
    DummyServer server;
    RedsysClient redsysClient;
    private int blockLength = 0;
    private int msgLength = 0;
    private boolean stxFound = false;

    private final byte DLE = 0x10;
    private final byte STX = 0x02;
    private final byte ETX = 0x03;
    private final byte ETB = 0x17;
    private final byte[] DlAk = {DLE, 0x06};
    private final byte[] DlNk = {DLE, 0x15};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.server_start).setOnClickListener(this);
        findViewById(R.id.server_stop).setOnClickListener(this);
        findViewById(R.id.server_stop).setEnabled(false);
        findViewById(R.id.client_connect).setOnClickListener(this);
        findViewById(R.id.client_disconnect).setOnClickListener(this);
        findViewById(R.id.client_disconnect).setEnabled(false);
        findViewById(R.id.client_send_data).setOnClickListener(this);
        findViewById(R.id.client_send_data).setEnabled(false);

        server = new DummyServer(this);
        redsysClient = new RedsysClient(this);
    }


    private int findDlSxIndex(byte[] buffer, int length) {
        for (int i = 0; i < length - 1; i++) {
            if (buffer[i] == DLE && buffer[i+1] == STX) {
                return i;
            }
        }

        return -1;
    }

    private int findDlEIndex(byte[] buffer, int length) {
        for (int i = 0; i < length - 1; i++) {
            if (buffer[i] == DLE &&
                    (buffer[i+1] == ETX || buffer[i+1] == ETB)) {
                return i;
            }
        }

        return -1;
    }

    private short calculateCRC16v41(byte[] buffer, int startPos, int length) {
        short crc = 0x0000;         // initial value
        int polynomial = 0x1021;    // 0001 0000 0010 0001  (0, 5, 12)

        for (int x = startPos; x < startPos + length; x++) {
            byte b = buffer[x];
            for (int y = 0; y < 8; y++) {
                boolean bit = ((b   >> (7-y) & 1) == 1);
                boolean c15 = ((crc >> 15    & 1) == 1);
                crc <<= 1;
                if (c15 ^ bit) crc ^= polynomial;
            }
        }

        return crc;
    }

    private void sendPupMessage(byte[] msg, int startPos, int length) throws IOException {
        // added Dlx + Dle + CRC
        byte[] data = new byte[length + 6];
        ByteBuffer buffer = ByteBuffer.wrap(data);
        buffer.order(ByteOrder.BIG_ENDIAN);
        buffer.put(DLE);
        buffer.put(STX);
        buffer.put(msg, startPos, length);
        buffer.put(DLE);
        buffer.put(ETX);
        // crc of msg + ETX
        short crc = calculateCRC16v41(data, 2, length + 2);
        buffer.putShort(crc);
        String value = BufferUtil.toHexString(buffer, 0, data.length);
        send(data, 0, data.length);
    }

    private void send(byte[] data, int startPos, int length) throws IOException {
//        Socket socket;
//        ServerSocket serverSocket = new ServerSocket(5000);
//        socket=serverSocket.accept();
        OutputStream outputStream = new OutputStream() {
            @Override
            public void write(int i) throws IOException {

            }
        };
        outputStream.write(data, startPos, length);
        outputStream.flush();
    }


    @Override
    public void onClick(View view) {
        String ip = ((EditText)findViewById(R.id.ipField)).getText().toString();
        int port = Integer.parseInt(((EditText)findViewById(R.id.portField)).getText().toString());

        switch (view.getId()) {
            case R.id.server_start:
                server.start(ip, port);
                findViewById(R.id.server_start).setEnabled(false);
                findViewById(R.id.server_stop).setEnabled(true);
                break;
            case R.id.server_stop:
                server.onDestroy();
                findViewById(R.id.server_start).setEnabled(true);
                findViewById(R.id.server_stop).setEnabled(false);
                break;
            case R.id.client_connect:
                redsysClient.connect(ip, port);
                findViewById(R.id.client_connect).setEnabled(false);
                findViewById(R.id.client_disconnect).setEnabled(true);
                findViewById(R.id.client_send_data).setEnabled(true);
                break;
            case R.id.client_disconnect:
                redsysClient.disconnect();
                findViewById(R.id.client_connect).setEnabled(true);
                findViewById(R.id.client_disconnect).setEnabled(false);
                findViewById(R.id.client_send_data).setEnabled(false);
                break;
            case R.id.client_send_data:
              //  Msg2000.ID
                byte[] data = {2,0,0,0,0,0,0,0,4,0,0,0,4,0,0,0,2,0,1,8,0,8,0,1,0,7,3,0,1,1,0};
               redsysClient.send(data);
//                try {
//                    Log.d("sendPupMessage", "sendPupMessage: ");
                  //  sendPupMessage(data,0,4);
                    Log.d("sendPupMessage", "sendPupMessage: 12");
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
                break;
        }
    }
}
