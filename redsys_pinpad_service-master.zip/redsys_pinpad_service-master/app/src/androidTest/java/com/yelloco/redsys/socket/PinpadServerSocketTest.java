package com.yelloco.redsys.socket;

import android.support.test.runner.AndroidJUnit4;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

/**
 * Created by trnguyen on 30/03/18.
 */
@RunWith(AndroidJUnit4.class)
public class PinpadServerSocketTest {
    static final int port = 5000;
    static final byte[] msg2000 = {
            0x10, 0x02, 0x32, 0x30, 0x30, 0x30, 0x30, 0x30,
            0x33, 0x34, 0x30, 0x30, 0x34, 0x30, 0x30, 0x30,
            0x36, 0x30, 0x32, 0x30, 0x31, 0x38, 0x30, 0x33,
            0x32, 0x39, 0x31, 0x34, 0x32, 0x32, 0x32, 0x37,
            0x40, 0x30, 0x30, 0x30, 0x10, 0x03, 0x1D, 0x2F
    };

    @Test
    public void testServerSocket() {
        new PinpadServerSocket(port);
        try {
            Socket socket = new Socket("127.0.0.1", port);
            OutputStream outputStream = socket.getOutputStream();
            outputStream.write(msg2000);
            outputStream.flush();

            byte[] tmpBuffer = new byte[1024];
            int tmpLength;
            while ((tmpLength = socket.getInputStream().read(tmpBuffer)) != -1) {
                Assert.assertEquals(tmpLength, 2);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to execute test", e);
        }

    }
}
