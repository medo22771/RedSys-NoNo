package com.yelloco.redsys.pup;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;

public class Msg2011  extends Msg {
    public static final String ID = "2011";

    private static final int MSG2011_PAUSE_STATE_OFF = 8;
    private static final int MSG2011_SEPARATOR_OFF = 12;
    private static final int MSG2011_PROPRIETARY_DATA_LENGTH_OFF = 13;
    private static final int MSG2011_PROPRIETARY_DATA_OFF = 16;

    private static final int MSG2011_PAUSE_STATE_SIZE = 4;

    private int pauseState;
    
    public void setPauseState(int pauseState) {
        this.pauseState = pauseState;
    }

    public byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, MSG2011_PAUSE_STATE_OFF, String.format("%04d", pauseState).getBytes(), MSG2011_PAUSE_STATE_SIZE);

        buffer.put(MSG_SEPARATOR);
        BufferUtil.put(buffer, String.format("%03d", getProprietaryDataLength()).getBytes(), 0, MSG_PROPRIETARY_DATA_LENGTH_SIZE);
        int dataLength = buffer.position();
        BufferUtil.put(buffer, MSG_LENGTH_FIELD_OFF, String.format("%04d", dataLength).getBytes());
        setLength(dataLength);

        return data;
    }
}
