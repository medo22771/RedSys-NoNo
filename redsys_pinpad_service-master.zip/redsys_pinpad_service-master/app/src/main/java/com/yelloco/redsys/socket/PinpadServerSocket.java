package com.yelloco.redsys.socket;

import android.util.Log;

import com.yelloco.redsys.R;
import com.yelloco.redsys.pup.Msg;
import com.yelloco.redsys.pup.Msg2000;
import com.yelloco.redsys.pup.Msg2001;
import com.yelloco.redsys.pup.Msg2010;
import com.yelloco.redsys.pup.Msg2011;
import com.yelloco.redsys.util.BufferUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

public class PinpadServerSocket extends Thread {
    private static final String TAG = PinpadServerSocket.class.getSimpleName();
    private ServerSocket serverSocket;
    private int port;
    private String address;

//    public PinpadServerSocket(int port) {
//        this.port = port;
//        start();
//    }

    public PinpadServerSocket( int port) {

        this.port = port;
        start();

    }



    public void onDestroy() {
        if (serverSocket != null) {
            try {
                serverSocket.close();
                Log.e(TAG, "Server socket closed");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }


    @Override
    public void run() {
        try {
            String response="";
            // create ServerSocket using specified port
            serverSocket = new ServerSocket(port);
            Log.e(TAG, "Server socket opened, port:" + port);

            while (true) {
                // block the call until connection is created and return
                // Socket object


                Socket socket = null;

                try{

                 socket = serverSocket.accept();

            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e(TAG, "IOException: " + e.getMessage());
            }
                Log.e(TAG, String.format("Connection created from %s:%d",
                        socket.getInetAddress(), socket.getPort()));

                SocketServerReplyThread socketServerReplyThread =
                        new SocketServerReplyThread(socket);
                Log.e(TAG,"Connection created from2");
                socketServerReplyThread.run();
                Log.e(TAG,"Connection created from1");
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Log.e(TAG, "IOException: " + e.getMessage());
        }
    }

    public static class SocketServerReplyThread extends Thread {
        private Socket socket;

        private int blockLength = 0;
        private int msgLength = 0;
        private boolean stxFound = false;

        private final byte DLE = 0x10;
        private final byte STX = 0x02;
        private final byte ETX = 0x03;
        private final byte ETB = 0x17;
        private final byte[] DlAk = {DLE, 0x06};
        private final byte[] DlNk = {DLE, 0x15};

        /* a msg contains
         *  - STX (2 bytes)
         *  - data (at least 8bytes: id (4 bytes) + length (4bytes))
         *  - ETX/ETB (2 bytes)
         *  - checksum (2 bytes)
         *  so the minimal size = 2 + 8 + 2 + 2 = 14
         */
        private final int MSG_MIN_LENGTH = 8;
        private final int BLOCK_MIN_LENGTH = 14;


        public SocketServerReplyThread(Socket socket) {
            this.socket = socket;
        }

//        public SocketServerReplyThread(SocketChannel socketChannel) {
//            this.socketChannel=socketChannel
//        }

        @Override
        public void run() {
            try {
                Log.e(TAG,"Connection created from3");
                InputStream inputStream = socket.getInputStream();


                int tmpLength = 0;
                blockLength = 0;
                msgLength = 0;
                byte[] tmpBuffer = new byte[1024];
                byte[] block = new byte[1024];
                byte[] msg = new byte[1024];

                /*
                 * notice: inputStream.read() will block if no data return
                 */
                Log.e(TAG,"Connection created from9");
                while ((tmpLength = inputStream.read(tmpBuffer)) != -1) {
                    Log.e(TAG,"Connection created from4");
                    System.arraycopy(tmpBuffer, 0, block, blockLength, tmpLength);
                    blockLength += tmpLength;
                    Log.e(TAG,"Connection created from44");
                    // a msg will be read when it got its minimal size
                    if (blockLength < BLOCK_MIN_LENGTH) {
                        continue;
                    }

                    if (!stxFound) {
                        int index = findDlSxIndex(block, blockLength);
                        if (index < 0) {
//                            continue;
                        }

                        /* remove all data before DlSx + DlSx
                         * we don't need DlSx for checksum calculation
                         */
                        System.arraycopy(block, index + 2, block, 0, blockLength - (index + 2));
                        blockLength -= index + 2;
                        stxFound = true;
                    }

                    int endIndex = findDlEIndex(block, blockLength);
                    // we should have DlEx/DlEb + 2 byte CRC
                    if (endIndex < 0 || blockLength < endIndex + 4) {
                      //  continue;
                    }
                    Log.e(TAG,"Connection created from45");
                    // we calculate checksum of (data + DlEx)
                    byte[] DlE = new byte[2];
                    System.arraycopy(block, endIndex, DlE, 0, 2);
                    short checksum = BufferUtil.getShort(block, endIndex + 2, ByteOrder.BIG_ENDIAN);
                    short verifiedChecksum = calculateCRC16v41(block, 0, endIndex + 2);

                    // reset block reading
                    blockLength = 0;
                    stxFound = false;

                    // send error in case that checksum verification fails
                    if (checksum != verifiedChecksum || endIndex < MSG_MIN_LENGTH) {
                        send(DlNk, 0, DlNk.length);
                        continue;
                    }
                    Log.e(TAG,"Connection created from4");
                    System.arraycopy(block, 0, msg, msgLength, endIndex);
                    msgLength += endIndex;
                    Log.e(TAG,"Connection created from5");
                    switch (DlE[1]) {
                    case ETX:
                        Log.e(TAG,"Connection created from6");
                        handleMessage(msg, msgLength);
                        Log.e(TAG,"Connection created from6");
                        //reset msg reading
                        msgLength = 0;
                        break;
                    case ETB:
                        send(DlAk, 0, DlAk.length);
                        break;
                    default:
                        throw new RuntimeException("It could not happen");
                    }
                }

                Log.e(TAG, String.format("Socket closed for %s:%d",
                        socket.getInetAddress(), socket.getPort()));
                Log.e(TAG,"Connection created from7");
            } catch (IOException e) {
                Log.e(TAG,"Connection created from8");
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e(TAG, "IOException: " + e.getMessage());
            }
        }

        private int findDlSxIndex(byte[] buffer, int length) {
            for (int i = 0; i < length - 1; i++) {
                if (buffer[i] == DLE && buffer[i+1] == STX) {
                    return i;
                }
            }

            return -1;
        }

        private int findDlEIndex(byte[] buffer, int length) {
            for (int i = 0; i < length - 1; i++) {
                if (buffer[i] == DLE &&
                        (buffer[i+1] == ETX || buffer[i+1] == ETB)) {
                    return i;
                }
            }

            return -1;
        }

        private short calculateCRC16v41(byte[] buffer, int startPos, int length) {
            short crc = 0x0000;         // initial value
            int polynomial = 0x1021;    // 0001 0000 0010 0001  (0, 5, 12)

            for (int x = startPos; x < startPos + length; x++) {
                byte b = buffer[x];
                for (int y = 0; y < 8; y++) {
                    boolean bit = ((b   >> (7-y) & 1) == 1);
                    boolean c15 = ((crc >> 15    & 1) == 1);
                    crc <<= 1;
                    if (c15 ^ bit) crc ^= polynomial;
                }
            }

            return crc;
        }

        public void sendPupMessage(byte[] msg, int startPos, int length) throws IOException {
            // added Dlx + Dle + CRC
            byte[] data = new byte[length + 6];
            ByteBuffer buffer = ByteBuffer.wrap(data);
            buffer.order(ByteOrder.BIG_ENDIAN);
            buffer.put(DLE);
            buffer.put(STX);
            buffer.put(msg, startPos, length);
            buffer.put(DLE);
            buffer.put(ETX);
            // crc of msg + ETX
            short crc = calculateCRC16v41(data, 2, length + 2);
            buffer.putShort(crc);
            String value = BufferUtil.toHexString(buffer, 0, data.length);
            send(data, 0, data.length);
        }

        private void send(byte[] data, int startPos, int length) throws IOException {
            OutputStream outputStream = socket.getOutputStream();
            outputStream.write(data, startPos, length);
            outputStream.flush();
        }

        private void handleMessage(byte[] data, int length) throws IOException  {
            Msg msg = new Msg(data, length);
            switch (msg.getId()) {
                case Msg2000.ID:
                    Msg2000 msg2000 = new Msg2000(data, length);
                    Log.d(TAG, "handleMessage: msg2000");
                    Msg2010 msg2010 = new Msg2010();
                    Log.d(TAG, "handleMessage: msg2010");
                    // set dummy data for msg2010
                    msg2010.fillForTesting();
                    Log.d(TAG, "handleMessage: msg2010 fillForTesting");
                    msg2010.printData();
                    Log.d(TAG, "handleMessage: msg2010 printData");
                    sendPupMessage(msg2010.toPupMessage(), 0, msg2010.getLength());
                    Log.d(TAG, "handleMessage: msg2010 sendPupMessage");
                    break;
                case Msg2001.ID:
                    Msg2001 msg2001 = new Msg2001(data, length);
                    Log.d(TAG, "handleMessage: msg2001");
                    Msg2011 msg2011 = new Msg2011();
                    Log.d(TAG, "handleMessage: msg2011");
                    msg2011.setPauseState(1);
                    Log.d(TAG, "handleMessage: msg2011 setPauseState");
                    sendPupMessage(msg2011.toPupMessage(), 0, msg2011.getLength());
                    Log.d(TAG, "handleMessage: msg2011 sendPupMessage");
                    break;
                default:
                    // we will have to implement everything
            }
        }
    }
}