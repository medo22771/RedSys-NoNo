package com.yelloco.redsys;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.yelloco.redsys.socket.PinpadServerSocket;

public class MainActivity extends AppCompatActivity {
    EditText portText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button send=findViewById(R.id.sendData);
        Context context = getApplicationContext();
        SharedPreferences preferences = getApplicationContext().getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        Integer server_port = preferences.getInt(context.getString(R.string.port_ref), getResources().getInteger(R.integer.server_port));

        portText = findViewById(R.id.portText);
        portText.setText(server_port.toString());
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                byte[] data = {2, 0, 0, 0,'.','I','D',9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9};

              //  new PinpadServerSocket.SocketServerReplyThread.(data,0,4);
            }
        });
    }

    public void startService(View view) {
        if (portText.getText().toString().isEmpty()) {
            portText.setError("Can't be empty");
            return;
        }

        Context context = getApplicationContext();
        SharedPreferences preferences = getApplicationContext().getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        preferences.edit().putInt(context.getString(R.string.port_ref), Integer.parseInt(portText.getText().toString()));
        preferences.edit().apply();

        startService(new Intent(getBaseContext(), PinpadService.class));
        findViewById(R.id.startButton).setEnabled(false);
        findViewById(R.id.stopButton).setEnabled(true);
    }

    public void stopService(View view) {
        stopService(new Intent(getBaseContext(), PinpadService.class));
        findViewById(R.id.startButton).setEnabled(true);
        findViewById(R.id.stopButton).setEnabled(false);
    }
}
