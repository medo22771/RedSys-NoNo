package com.yelloco.redsys;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;

import com.yelloco.redsys.socket.PinpadServerSocket;

/**
 * Created by trnguyen on 29/03/18.
 */

public class PinpadService extends Service {
    PinpadServerSocket socketServer;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        Context context = getApplicationContext();
        SharedPreferences preferences = context.getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        int server_port = preferences.getInt(context.getString(R.string.port_ref), getResources().getInteger(R.integer.server_port));
        socketServer = new PinpadServerSocket(server_port);
    }

    public void onDestroy() {
        socketServer.onDestroy();
    }
}
