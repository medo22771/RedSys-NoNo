package com.yelloco.redsys.pup;

/**
 * Created by trnguyen on 30/03/18.
 */

public class Msg2001 extends Msg {
    public static final String ID = "2001";

    private static final int MSG2001_PAUSE_STATE_OFF= 8;
    private static final int MSG2001_SEPARATOR_OFF= 12;
    private static final int MSG2001_PROPRIETARY_DATA_LENGTH_OFF = 13;
    private static final int MSG2001_PROPRIETARY_DATA_OFF = 16;

    private static final int MSG2001_PAUSE_STATE_SIZE = 4;

    private int pauseState;

    public Msg2001(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public int getPauseState() {
        return pauseState;
    }

    public void fromPupMessage(byte[] data) {
        pauseState = Integer.parseInt(new String(data, MSG2001_PAUSE_STATE_OFF, MSG2001_PAUSE_STATE_SIZE));
        setProprietaryData(data, MSG2001_PROPRIETARY_DATA_LENGTH_OFF);
    }
}
