package com.yelloco.redsys.pup;

public class Msg0200 extends Msg {


    public static final String ID = "0200";

    private static int LBIN=0;
    private static int card_bin = 0;
    private static short track_encryption =0 ;
    private static short identifier_of_the_key=0;
    private static int LRESPA = 0;
    private static String response_to_authontication;
    private static int estado=0;
    private static String terminal_action_code;
    private static String random_num_of_ciphering_track;
    private static int separator=0;
    private static int signature_length = 0;
    private static int scanned_signature =0 ;




    private static final int Msg0200_LBIN= 8;
    private static final int Msg0200_CARD_BIN= 10;
    private static int Msg0200_TRACK_ENCRYPTION= 10+LBIN;
    private static int Msg0200_IDENTIFIER_OF_THE_KEY= 11+LBIN;
    private static int Msg0200_LRESPA= 12+LBIN;
    private static int Msg0200_RESPONSE_TO_AUTHONTICATION= 16+LBIN;
    private static int Msg0200_ESTADO= 16+LBIN+LRESPA;
    private static int Msg0200_TERMINAL_ACTION_CODES= 20+LBIN+LRESPA;
    private static int Msg0200_RANDOM_NUM_CIPHERING_TRACK= 50+LBIN+LRESPA;
    private static int Msg0200_SEPARATOR= 56+LBIN+LRESPA;
    private static int Msg0200_SIGNATURE_LENGTH= 57+LBIN+LRESPA;
    private static int Msg0200_SCANNED_SIGNATURE= 61+LBIN+LRESPA;


    private static final int MSG0200_SEPARATOR_OFF= 61+LBIN+LRESPA+signature_length;
    private static int MSG0200_PROPRIETARY_DATA_LENGTH_OFF = 62+LBIN+LRESPA+signature_length;
    private static final int MS0200_PROPRIETARY_DATA_OFF = 65+LBIN+LRESPA+signature_length;



    private static final int Msg0200_LBIN_SIZE= 2;
    private static int Msg0200_CARD_BIN_SIZE= LBIN;
    private static final int Msg0200_TRACK_ENCRYPTION_SIZE= 1;
    private static final int Msg0200_IDENTIFIER_OF_THE_KEY_SIZE= 1;
    private static final int Msg0200_LRESPA_SIZE= 4;
    private static int Msg0200_RESPONSE_TO_AUTHONTICATION_SIZE= LRESPA;
    private static final int Msg0200_ESTADO_SIZE= 4;
    private static final int Msg0200_TERMINAL_ACTION_CODES_SIZE= 30;
    private static final int Msg0200_RANDOM_NUM_CIPHERING_TRACK_SIZE= 6;
    private static final int Msg0200_SEPARATOR_SIZE= 1;
    private static final int Msg0200_SIGNATURE_LENGTH_SIZE= 4;
    private static int Msg0200_SCANNED_SIGNATURE_SIZE= signature_length;



    public Msg0200(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        LBIN = Integer.parseInt(new String(data, Msg0200_LBIN, Msg0200_LBIN_SIZE));
        Msg0200_CARD_BIN_SIZE= LBIN;
        card_bin = Integer.parseInt(new String(data, Msg0200_CARD_BIN, Msg0200_CARD_BIN_SIZE));
        Msg0200_TRACK_ENCRYPTION= 10+LBIN;
        track_encryption = (short) Integer.parseInt(new String(data, Msg0200_TRACK_ENCRYPTION, Msg0200_TRACK_ENCRYPTION_SIZE));
        Msg0200_IDENTIFIER_OF_THE_KEY= 11+LBIN;
        identifier_of_the_key = (short) Integer.parseInt(new String(data, Msg0200_IDENTIFIER_OF_THE_KEY, Msg0200_IDENTIFIER_OF_THE_KEY_SIZE));
        Msg0200_LRESPA= 12+LBIN;
        LRESPA = Integer.parseInt(new String(data, Msg0200_LRESPA, Msg0200_LRESPA_SIZE));
        Msg0200_RESPONSE_TO_AUTHONTICATION= 16+LBIN;
        Msg0200_RESPONSE_TO_AUTHONTICATION_SIZE= LRESPA;
        response_to_authontication = (new String(data, Msg0200_RESPONSE_TO_AUTHONTICATION, Msg0200_RESPONSE_TO_AUTHONTICATION_SIZE));
        Msg0200_ESTADO= 16+LBIN+LRESPA;
        estado = Integer.parseInt(new String(data, Msg0200_ESTADO, Msg0200_ESTADO_SIZE));
        Msg0200_TERMINAL_ACTION_CODES= 20+LBIN+LRESPA;
        terminal_action_code = (new String(data, Msg0200_TERMINAL_ACTION_CODES, Msg0200_TERMINAL_ACTION_CODES_SIZE));
        Msg0200_RANDOM_NUM_CIPHERING_TRACK= 50+LBIN+LRESPA;
        random_num_of_ciphering_track = (new String(data, Msg0200_RANDOM_NUM_CIPHERING_TRACK, Msg0200_RANDOM_NUM_CIPHERING_TRACK_SIZE));
        Msg0200_SEPARATOR= 56+LBIN+LRESPA;
        separator = Integer.parseInt(new String(data, Msg0200_SEPARATOR, Msg0200_SEPARATOR_SIZE));
        Msg0200_SIGNATURE_LENGTH= 57+LBIN+LRESPA;
        signature_length = Integer.parseInt(new String(data, Msg0200_SIGNATURE_LENGTH, Msg0200_SIGNATURE_LENGTH_SIZE));
        Msg0200_SCANNED_SIGNATURE= 61+LBIN+LRESPA;
        Msg0200_SCANNED_SIGNATURE_SIZE= signature_length;
        scanned_signature = Integer.parseInt(new String(data, Msg0200_SCANNED_SIGNATURE, Msg0200_SCANNED_SIGNATURE_SIZE));
        MSG0200_PROPRIETARY_DATA_LENGTH_OFF = 62+LBIN+LRESPA+signature_length;

        setProprietaryData(data, MSG0200_PROPRIETARY_DATA_LENGTH_OFF);
    }


}
