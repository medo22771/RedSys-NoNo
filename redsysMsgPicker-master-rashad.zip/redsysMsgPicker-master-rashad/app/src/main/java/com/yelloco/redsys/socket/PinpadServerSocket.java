package com.yelloco.redsys.socket;

import android.util.Log;

import com.yelloco.redsys.pup.Msg;
import com.yelloco.redsys.pup.Msg0010;
import com.yelloco.redsys.pup.Msg0020;
import com.yelloco.redsys.pup.Msg0030;
import com.yelloco.redsys.pup.Msg0040;
import com.yelloco.redsys.pup.Msg0050;
import com.yelloco.redsys.pup.Msg0060;
import com.yelloco.redsys.pup.Msg0070;
import com.yelloco.redsys.pup.Msg0080;
import com.yelloco.redsys.pup.Msg0101;
import com.yelloco.redsys.pup.Msg0102;
import com.yelloco.redsys.pup.Msg0111;
import com.yelloco.redsys.pup.Msg0112;
import com.yelloco.redsys.pup.Msg0200;
import com.yelloco.redsys.pup.Msg0210;
import com.yelloco.redsys.pup.Msg0300;
import com.yelloco.redsys.pup.Msg0310;
import com.yelloco.redsys.pup.Msg1000;
import com.yelloco.redsys.pup.Msg1001;
import com.yelloco.redsys.pup.Msg1010;
import com.yelloco.redsys.pup.Msg1011;
import com.yelloco.redsys.pup.Msg2000;
import com.yelloco.redsys.pup.Msg2001;
import com.yelloco.redsys.pup.Msg2010;
import com.yelloco.redsys.pup.Msg2011;
import com.yelloco.redsys.pup.Msg3000;
import com.yelloco.redsys.pup.Msg3010;
import com.yelloco.redsys.pup.Msg4001;
import com.yelloco.redsys.pup.Msg4002;
import com.yelloco.redsys.pup.Msg4003;
import com.yelloco.redsys.pup.Msg4011;
import com.yelloco.redsys.pup.Msg4012;
import com.yelloco.redsys.pup.Msg4013;
import com.yelloco.redsys.util.BufferUtil;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class PinpadServerSocket extends Thread {
    private static final String TAG = PinpadServerSocket.class.getSimpleName();
    private ServerSocket serverSocket;
    private int port;

    public PinpadServerSocket(int port) {
        this.port = port;
        start();
    }

    public void onDestroy() {
        if (serverSocket != null) {
            try {
                serverSocket.close();
                Log.e(TAG, "Server socket closed");
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    @Override
    public void run() {
        try {
            // create ServerSocket using specified port
            serverSocket = new ServerSocket(port);
            Log.e(TAG, "Server socket opened, port:" + port);

            while (true) {
                // block the call until connection is created and return
                // Socket object
                Socket socket = serverSocket.accept();
                Log.e(TAG, String.format("Connection created from %s:%d",
                        socket.getInetAddress(), socket.getPort()));

                SocketServerReplyThread socketServerReplyThread =
                        new SocketServerReplyThread(socket);
                socketServerReplyThread.run();
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Log.e(TAG, "IOException: " + e.getMessage());
        }
    }

    private class SocketServerReplyThread extends Thread {
        private Socket socket;

        private int blockLength = 0;
        private int msgLength = 0;
        private boolean stxFound = false;

        private final byte DLE = 0x10;
        private final byte STX = 0x02;
        private final byte ETX = 0x03;
        private final byte ETB = 0x17;
        private final byte[] DlAk = {DLE, 0x06};
        private final byte[] DlNk = {DLE, 0x15};

        /* a msg contains
         *  - STX (2 bytes)
         *  - data (at least 8bytes: id (4 bytes) + length (4bytes))
         *  - ETX/ETB (2 bytes)
         *  - checksum (2 bytes)
         *  so the minimal size = 2 + 8 + 2 + 2 = 14
         */
        private final int MSG_MIN_LENGTH = 8;
        private final int BLOCK_MIN_LENGTH = 14;


        SocketServerReplyThread(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                InputStream inputStream = socket.getInputStream();


                int tmpLength = 0;
                blockLength = 0;
                msgLength = 0;
                byte[] tmpBuffer = new byte[1024];
                byte[] block = new byte[1024];
                byte[] msg = new byte[1024];


                /*
                 * notice: inputStream.read() will block if no data return
                 */
                while ((tmpLength = inputStream.read(tmpBuffer)) != -1) {
                    System.arraycopy(tmpBuffer, 0, block, blockLength, tmpLength);
                    blockLength += tmpLength;

                    // a msg will be read when it got its minimal size
                    if (blockLength < BLOCK_MIN_LENGTH) {
                        continue;
                    }

                    if (!stxFound) {
                        int index = findDlSxIndex(block, blockLength);
                        if (index < 0) {
                            continue;
                        }

                        /* remove all data before DlSx + DlSx
                         * we don't need DlSx for checksum calculation
                         */
                        System.arraycopy(block, index + 2, block, 0, blockLength - (index + 2));
                        blockLength -= index + 2;
                        stxFound = true;
                    }

                    int endIndex = findDlEIndex(block, blockLength);
                    // we should have DlEx/DlEb + 2 byte CRC
                    if (endIndex < 0 || blockLength < endIndex + 4) {
                        continue;
                    }

                    // we calculate checksum of (data + DlEx)
                    byte[] DlE = new byte[2];
                    System.arraycopy(block, endIndex, DlE, 0, 2);
                    short checksum = BufferUtil.getShort(block, endIndex + 2, ByteOrder.BIG_ENDIAN);
                    short verifiedChecksum = calculateCRC16v41(block, 0, endIndex + 2);

                    // reset block reading
                    blockLength = 0;
                    stxFound = false;

                    // send error in case that checksum verification fails
                    if (checksum != verifiedChecksum || endIndex < MSG_MIN_LENGTH) {
                        send(DlNk, 0, DlNk.length);
                        continue;
                    }

                    System.arraycopy(block, 0, msg, msgLength, endIndex);
                    msgLength += endIndex;

                    switch (DlE[1]) {
                    case ETX:
                        handleMessage(msg, msgLength);
                        //reset msg reading
                        msgLength = 0;
                        break;
                    case ETB:
                        send(DlAk, 0, DlAk.length);
                        break;
                    default:
                        throw new RuntimeException("It could not happen");
                    }
                }

                Log.e(TAG, String.format("Socket closed for %s:%d",
                        socket.getInetAddress(), socket.getPort()));
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                Log.e(TAG, "IOException: " + e.getMessage());
            }
        }

        private int findDlSxIndex(byte[] buffer, int length) {
            for (int i = 0; i < length - 1; i++) {
                if (buffer[i] == DLE && buffer[i+1] == STX) {
                    return i;
                }
            }

            return -1;
        }

        private int findDlEIndex(byte[] buffer, int length) {
            for (int i = 0; i < length - 1; i++) {
                if (buffer[i] == DLE &&
                        (buffer[i+1] == ETX || buffer[i+1] == ETB)) {
                    return i;
                }
            }

            return -1;
        }

        private short calculateCRC16v41(byte[] buffer, int startPos, int length) {
            short crc = 0x0000;         // initial value
            int polynomial = 0x1021;    // 0001 0000 0010 0001  (0, 5, 12)

            for (int x = startPos; x < startPos + length; x++) {
                byte b = buffer[x];
                for (int y = 0; y < 8; y++) {
                    boolean bit = ((b   >> (7-y) & 1) == 1);
                    boolean c15 = ((crc >> 15    & 1) == 1);
                    crc <<= 1;
                    if (c15 ^ bit) crc ^= polynomial;
                }
            }

            return crc;
        }

        private void sendPupMessage(byte[] msg, int startPos, int length) throws IOException {
            // added Dlx + Dle + CRC
            byte[] data = new byte[length + 6];
            ByteBuffer buffer = ByteBuffer.wrap(data);
            buffer.order(ByteOrder.BIG_ENDIAN);
            buffer.put(DLE);
            buffer.put(STX);
            buffer.put(msg, startPos, length);
            buffer.put(DLE);
            buffer.put(ETX);
            // crc of msg + ETX
            short crc = calculateCRC16v41(data, 2, length + 2);
            buffer.putShort(crc);
            String value = BufferUtil.toHexString(buffer, 0, data.length);
            send(data, 0, data.length);
        }

        private void send(byte[] data, int startPos, int length) throws IOException {
            OutputStream outputStream = socket.getOutputStream();
            outputStream.write(data, startPos, length);
            outputStream.flush();
        }

        private void handleMessage(byte[] data, int length) throws IOException  {
            Msg msg = new Msg(data, length);
            switch (msg.getId()) {
                case Msg2000.ID:
                    Msg2000 msg2000 = new Msg2000(data, length);
                    Msg2010 msg2010 = new Msg2010();
                    // set dummy data for msg2010
                    msg2010.fillForTesting();
                    msg2010.printData();
                    sendPupMessage(msg2010.toPupMessage(), 0, msg2010.getLength());
                    break;
                case Msg2001.ID:
                    Msg2001 msg2001 = new Msg2001(data, length);
                    Msg2011 msg2011 = new Msg2011();
//                    msg2011.setPauseState(1);
                    sendPupMessage(msg2011.toPupMessage(), 0, msg2011.getLength());
                    break;
                case Msg1000.ID:
                    Msg1000 msg1000 = new Msg1000(data, length);
                    Msg1010 msg1010 = new Msg1010();
                    msg1010.fillForTesting();
                    sendPupMessage(Msg1010.toPupMessage(), 0, Msg1010.getLength());
                    break;
                case Msg1001.ID:
                    Msg1001 msg1001 = new Msg1001(data, length);
                    Msg1011 msg1011 = new Msg1011();
                    msg1011.fillForTesting();
                    sendPupMessage(Msg1011.toPupMessage(), 0, Msg1011.getLength());
                    break;
                case Msg0010.ID:
                    Msg0010 msg0010 = new Msg0010(data, length);
                    Msg0020 msg0020 = new Msg0020();
                    msg0020.fillForTesting();
                    sendPupMessage(Msg0020.toPupMessage(), 0, Msg0020.getLength());
                    break;
                case Msg0101.ID:
                    Msg0101 msg0101 = new Msg0101(data, length);
                    Msg0111 msg0111 = new Msg0111();
                    msg0111.fillForTesting();
                    sendPupMessage(Msg0111.toPupMessage(), 0, Msg0111.getLength());
                    break;
                case Msg0102.ID:
                    Msg0102 msg0102 = new Msg0102(data, length);
                    Msg0112 msg0112 = new Msg0112();
                    msg0112.fillForTesting();
                    sendPupMessage(Msg0112.toPupMessage(), 0, Msg0112.getLength());
                    break;
                case Msg0200.ID:
                    Msg0102 msg0200 = new Msg0102(data, length);
                    Msg0210 msg0210 = new Msg0210();
                    msg0210.fillForTesting();
                    sendPupMessage(Msg0210.toPupMessage(), 0, Msg0210.getLength());
                    break;
                case Msg0300.ID:
                    Msg0300 msg0300 = new Msg0300(data, length);
                    Msg0310 msg0310 = new Msg0310();
                    msg0310.fillForTesting();
                    sendPupMessage(Msg0310.toPupMessage(), 0, Msg0310.getLength());
                    break;
                case Msg0030.ID:
                    Msg0030 msg0030 = new Msg0030(data, length);
                    Msg0040 msg0040 = new Msg0040();
                    msg0040.fillForTesting();
                    sendPupMessage(Msg0040.toPupMessage(), 0, Msg0040.getLength());
                    break;
                case Msg0050.ID:
                    Msg0050 msg0050 = new Msg0050(data, length);
                    Msg0060 msg0060 = new Msg0060();
                    msg0060.fillForTesting();
                    sendPupMessage(Msg0060.toPupMessage(), 0, Msg0060.getLength());
                    break;
                case Msg0070.ID:
                    Msg0070 msg0070 = new Msg0070(data, length);
                    Msg0080 msg0080 = new Msg0080();
                    msg0080.fillForTesting();
                    sendPupMessage(Msg0080.toPupMessage(), 0, Msg0080.getLength());
                    break;
                case Msg3000.ID:
                    Msg3000 msg3000 = new Msg3000(data, length);
                    Msg3010 msg3010 = new Msg3010();
                    msg3010.fillForTesting();
                    sendPupMessage(Msg3010.toPupMessage(), 0, Msg3010.getLength());
                    break;
                case Msg4001.ID:
                    Msg4001 msg4001 = new Msg4001(data, length);
                    Msg4011 msg4011 = new Msg4011();
                    msg4011.fillForTesting();
                    sendPupMessage(Msg4011.toPupMessage(), 0, Msg4011.getLength());
                    break;
                case Msg4002.ID:
                    Msg4002 msg4002 = new Msg4002(data, length);
                    Msg4012 msg4012 = new Msg4012();
                    msg4012.fillForTesting();
                    sendPupMessage(Msg4012.toPupMessage(), 0, Msg4012.getLength());
                    break;
                case Msg4003.ID:
                    Msg4003 msg4003 = new Msg4003(data, length);
                    Msg4013 msg4013 = new Msg4013();
                    msg4013.fillForTesting();
                    sendPupMessage(Msg4013.toPupMessage(), 0, Msg4013.getLength());
                    break;

                default:
                    // we will have to implement everything
            }
        }
    }
}