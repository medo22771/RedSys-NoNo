package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;

/**
 * Created by Desktop 10 on 4/12/2018.
 */

public class Msg3000 extends Msg {

    public static final String ID = "3000";

    private static final int MSG3000_EMP_PARAMETER_VERSION = 8;
    private static final int MSG3000_PUBLIC_KEY_VERSION = 11;
    private static final int MSG3000_SEPARATOR_BETWEEN_BLOCKS = 14;
    private static final int MSG3000_BLOCK_CONFIGURATION_PARAMETER = 15;
    private static final int MSG3000_SECURITY_DATA= 17;
    private static final int MSG3000_SEPARATOR= 27;
    private static final int MSG3000_IDENTIFIER_OF_THE_KEY = 28;
    private static final int MSG3000_TRACK_ENCRYPTION = 29;

    private static final int MSG3000_SEPARATOR_OFF= 45;
    private static final int MSG3000_PROPRIETARY_DATA_LENGTH_OFF = 46;
    private static final int MSG3000_PROPRIETARY_DATA_OFF = 49;

    private static final int MSG3000_EMP_PARAMETER_VERSION_SIZE = 3;
    private static final int MSG3000_PUBLIC_KEY_VERSION_SIZE= 3;
    private static final int MSG3000_SEPARATOR_BETWEEN_BLOCKS_SIZE = 1;
    private static final int MSG3000_BLOCK_CONFIGURATION_PARAMETER_SIZE= 2;
    private static final int MSG3000_SECURITY_DATA_SIZE= 10;
    private static final int MSG3000_SEPARATOR_SIZE= 1;
    private static final int MSG3000_IDENTIFIER_OF_THE_KEY_SIZE= 1;
    private static final int MSG3000_TRACK_ENCRYPTION_SIZE= 16;


    private String emv_parameter_version;
    private int key_version;
    private String separator_between_blocks;
    private String block_conf_parameter;
    private String security_data;
    private String separator;
    private String identifier_of_the_key;
    private int track_encryption;

    public Msg3000(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        emv_parameter_version = (new String(data, MSG3000_EMP_PARAMETER_VERSION, MSG3000_EMP_PARAMETER_VERSION_SIZE));
        key_version = Integer.parseInt(new String(data, MSG3000_PUBLIC_KEY_VERSION, MSG3000_PUBLIC_KEY_VERSION_SIZE));
        separator_between_blocks = (new String(data, MSG3000_SEPARATOR_BETWEEN_BLOCKS, MSG3000_SEPARATOR_BETWEEN_BLOCKS_SIZE));
        block_conf_parameter = (new String(data, MSG3000_BLOCK_CONFIGURATION_PARAMETER, MSG3000_BLOCK_CONFIGURATION_PARAMETER_SIZE));
        security_data = (new String(data, MSG3000_SECURITY_DATA, MSG3000_SECURITY_DATA_SIZE));
        separator = (new String(data, MSG3000_SEPARATOR, MSG3000_SEPARATOR_SIZE));
        identifier_of_the_key = (new String(data, MSG3000_IDENTIFIER_OF_THE_KEY, MSG3000_IDENTIFIER_OF_THE_KEY_SIZE));
        track_encryption = Integer.parseInt(new String(data, MSG3000_TRACK_ENCRYPTION, MSG3000_TRACK_ENCRYPTION_SIZE));
        setProprietaryData(data, MSG3000_PROPRIETARY_DATA_LENGTH_OFF);

    }



}
