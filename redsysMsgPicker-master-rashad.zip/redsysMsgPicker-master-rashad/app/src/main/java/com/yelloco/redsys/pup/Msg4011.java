package com.yelloco.redsys.pup;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;

public class Msg4011 extends Msg {


    public static final String ID = "4011";

    private static final int MSG4011_STATE = 8;
    private static final int MSG4011_MAX_SIZE_DATA_RECEPTION_BUFFER= 9;
    private static final int MSG4011_BLOCK_NUM_RECEIVED_CORRECTLY = 17;
    private static final int MSG4011_NAME_OF_PRO_TO_DOWNLOAD= 20;
    private static final int MSG4011_PROGRAM_VERSION_TO_DOWNLOAD= 28;
    private static final int MSG4011_DOWNLOAD_FILE= 32;
    private static final int MSG4011_TOTAL_FILE_TO_DOWNLOAD= 34;

    private static final int MSG4011_SEPARATOR_OFF= 36;
    private static final int MSG4011_PROPRIETARY_DATA_LENGTH_OFF = 37;
    private static final int MSG4011_PROPRIETARY_DATA_OFF = 40;

    private static final int MSG4011_STATE_SIZE = 1;
    private static final int MSG4011_MAX_SIZE_DATA_RECEPTION_BUFFER_SIZE= 8;
    private static final int MSG4011_BLOCK_NUM_RECEIVED_CORRECTLY_SIZE = 3;
    private static final int MSG4011_NAME_OF_PRO_TO_DOWNLOAD_SIZE= 8;
    private static final int MSG4011_PROGRAM_VERSION_TO_DOWNLOAD_SIZE= 4;
    private static final int MSG4011_DOWNLOAD_FILE_SIZE= 2;
    private static final int MSG4011_TOTAL_FILE_TO_DOWNLOAD_SIZE= 2;


    private static short STATE;
    private static int receiption_buffer_max_size;
    private static int block_num_received_correctly;
    private static String name_of_pro_to_download;
    private static String pro_version;
    private static short download_file;
    private static short total_file_to_download;
    private static short deskNumber;
    private static byte pciScenario;

//    public Msg4011(byte[] data, int length) {
//        super(data, length);
//        fromPupMessage(data);
//    }
//
//    public void fromPupMessage(byte[] data) {
//        ByteBuffer buffer = ByteBuffer.wrap(data);
//        STATE = (short) Integer.parseInt(new String(data, MSG4011_STATE, MSG4011_STATE_SIZE));
//        receiption_buffer_max_size = Integer.parseInt(new String(data, MSG4011_MAX_SIZE_DATA_RECEPTION_BUFFER, MSG4011_MAX_SIZE_DATA_RECEPTION_BUFFER_SIZE));
//        block_num_received_correctly = Integer.parseInt(new String(data, MSG4011_BLOCK_NUM_RECEIVED_CORRECTLY, MSG4011_BLOCK_NUM_RECEIVED_CORRECTLY_SIZE));
//        name_of_pro_to_download = (new String(data, MSG4011_NAME_OF_PRO_TO_DOWNLOAD, MSG4011_NAME_OF_PRO_TO_DOWNLOAD_SIZE));
//        pro_version = (new String(data, MSG4011_PROGRAM_VERSION_TO_DOWNLOAD, MSG4011_PROGRAM_VERSION_TO_DOWNLOAD_SIZE));
//        download_file = Integer.parseInt(new String(data, MSG4011_DOWNLOAD_FILE, MSG4011_DOWNLOAD_FILE_SIZE));
//        total_file_to_download = Integer.parseInt(new String(data, MSG4011_TOTAL_FILE_TO_DOWNLOAD, MSG4011_TOTAL_FILE_TO_DOWNLOAD_SIZE));
//        setProprietaryData(data, MSG4011_PROPRIETARY_DATA_LENGTH_OFF);
//
//    }

    public void fillForTesting() {
        setSTATE((short) 0001);
        setReceiption_buffer_max_size(10000010);
        setBlock_num_received_correctly(001);
        setName_of_pro_to_download("00100101");
        setPro_version("0010");
        setDownload_file((short) 01);
        setTotal_file_to_download((short) 01);
    }


    public static byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, MSG4011_STATE, String.format("%04d", STATE).getBytes(), MSG4011_STATE_SIZE);
        BufferUtil.put(buffer, MSG4011_MAX_SIZE_DATA_RECEPTION_BUFFER, String.format("%01d", receiption_buffer_max_size).getBytes(), MSG4011_MAX_SIZE_DATA_RECEPTION_BUFFER_SIZE);
        BufferUtil.put(buffer, MSG4011_BLOCK_NUM_RECEIVED_CORRECTLY, String.format("%08d", block_num_received_correctly).getBytes(), MSG4011_BLOCK_NUM_RECEIVED_CORRECTLY_SIZE);
        BufferUtil.put(buffer, MSG4011_NAME_OF_PRO_TO_DOWNLOAD, name_of_pro_to_download.getBytes(), MSG4011_NAME_OF_PRO_TO_DOWNLOAD_SIZE);
        BufferUtil.put(buffer, MSG4011_PROGRAM_VERSION_TO_DOWNLOAD, pro_version.getBytes(), MSG4011_PROGRAM_VERSION_TO_DOWNLOAD_SIZE);
        BufferUtil.put(buffer, MSG4011_DOWNLOAD_FILE, String.format("%02d", download_file).getBytes(), MSG4011_DOWNLOAD_FILE_SIZE);
        BufferUtil.put(buffer, MSG4011_TOTAL_FILE_TO_DOWNLOAD, String.format("%02d", total_file_to_download).getBytes(), MSG4011_TOTAL_FILE_TO_DOWNLOAD_SIZE);

        if (deskNumber > 0) {
            // not happen yet
        }
        buffer.put(pciScenario);

        buffer.put(MSG_SEPARATOR);
        BufferUtil.put(buffer, String.format("%03d", getProprietaryDataLength()).getBytes(), 0, MSG_PROPRIETARY_DATA_LENGTH_SIZE);
        int dataLength = buffer.position();

        // setLength of the buffer
        BufferUtil.put(buffer, MSG_LENGTH_FIELD_OFF, String.format("%04d", dataLength).getBytes());
        setLength(dataLength);

        return data;
    }


    public static void setSTATE(short STATE) {
        Msg4011.STATE = STATE;
    }

    public void setReceiption_buffer_max_size(int receiption_buffer_max_size) {
        this.receiption_buffer_max_size = receiption_buffer_max_size;
    }

    public void setBlock_num_received_correctly(int block_num_received_correctly) {
        this.block_num_received_correctly = block_num_received_correctly;
    }

    public void setName_of_pro_to_download(String name_of_pro_to_download) {
        this.name_of_pro_to_download = name_of_pro_to_download;
    }

    public void setPro_version(String pro_version) {
        this.pro_version = pro_version;
    }

    public void setDownload_file(short download_file) {
        this.download_file = download_file;
    }

    public void setTotal_file_to_download(short total_file_to_download) {
        this.total_file_to_download = total_file_to_download;
    }
}
