package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Msg2000 extends Msg {
    public static final String ID = "2000";

    private static final int MSG2000_MESSENGER_TIMEOUT_OFF = 8;
    private static final int MSG2000_USER_TIMEOUT_OFF= 12;
    private static final int MSG2000_LOCAL_TIME_OFF = 16;

    private static final int MSG2000_SEPARATOR_OFF= 30;
    private static final int MSG2000_PROPRIETARY_DATA_LENGTH_OFF = 31;
    private static final int MSG2000_PROPRIETARY_DATA_OFF = 34;

    private static final int MSG2000_MESSENGER_TIMEOUT_SIZE = 4;
    private static final int MSG2000_USER_TIMEOUT_SIZE = 4;
    private static final int MSG2000_LOCAL_TIME_SIZE = 14;


    private int messengerTimeout;
    private int userTimeout;
    private Calendar localTime;

    public Msg2000(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        messengerTimeout = Integer.parseInt(new String(data, MSG2000_MESSENGER_TIMEOUT_OFF, MSG2000_MESSENGER_TIMEOUT_SIZE));
        userTimeout = Integer.parseInt(new String(data, MSG2000_USER_TIMEOUT_OFF, MSG2000_USER_TIMEOUT_SIZE));
        localTime = Calendar.getInstance();
        String tmpTime = new String(data, MSG2000_LOCAL_TIME_OFF, MSG2000_LOCAL_TIME_SIZE);
        try {
            localTime.setTime(new SimpleDateFormat("yyyyMMddHHmmss").parse(tmpTime));
        } catch (Exception e) {
            throw new RuntimeException("Error parsing time", e);
        }
        setProprietaryData(data, MSG2000_PROPRIETARY_DATA_LENGTH_OFF);
    }

    public void setMessengerTimeout(int messengerTimeout) {
        this.messengerTimeout = messengerTimeout;
    }

    public void setUserTimeout(int userTimeout) {
        this.userTimeout = userTimeout;
    }

    public void setLocalTime(Calendar localTime) {
        this.localTime = localTime;
    }
}