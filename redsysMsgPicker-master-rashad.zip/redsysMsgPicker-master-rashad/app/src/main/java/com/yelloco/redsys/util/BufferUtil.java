package com.yelloco.redsys.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Created by trnguyen on 03/04/18.
 */

public class BufferUtil {
    /**
     * get short from a byte array
     * @param data  byte array
     * @param startPos the position of the short value
     * @param order LITTLE_INDIEN or BIG_INDIEN
     * @return
     */
    static public short getShort(byte[] data, int startPos, ByteOrder order) {
        ByteBuffer buffer = ByteBuffer.wrap(data, startPos, 2);
        buffer.order(order);
        return buffer.getShort();
    }

    /**
     * put data into a ByteBuffer
     * @param buffer        buffer object
     * @param bufferOffset  buffer offset to put data into
     * @param data          data
     */
    static public void put(ByteBuffer buffer, int bufferOffset, byte[] data) {
        buffer.position(bufferOffset);
        put(buffer, data, 0, data.length);
    }

    /**
     * put data into a ByteBuffer
     * @param buffer        buffer object
     * @param bufferOffset  buffer offset to put data into
     * @param data          data
     * @param length        data length
     */
    static public void put(ByteBuffer buffer, int bufferOffset, byte[] data, int length) {
        buffer.position(bufferOffset);
        put(buffer, data, 0, length);
    }

    /**
     * put data into a ByteBuffer
     * @param buffer        buffer object
     * @param bufferOffset  buffer offset to put data into
     * @param data          data
     * @param dataOffset    data offset
     * @param length        data length
     */
    static public void put(ByteBuffer buffer, int bufferOffset, byte[] data, int dataOffset, int length) {
        buffer.position(bufferOffset);
        put(buffer, data, dataOffset, length);
    }

    /**
     * put data into a ByteBuffer
     * @param buffer        buffer object
     * @param data          data
     * @param dataOffset    data offset
     * @param length        data length
     */
    static public void put(ByteBuffer buffer, byte[] data, int dataOffset, int length) {
        int dataLength = (data.length - dataOffset >= length ? length : data.length - dataOffset);
        buffer.put(data, dataOffset, dataLength);
    }

    /**
     * print buffer in hex String
     * @param buffer
     * @param length
     * @return
     */
    static public String toHexString(ByteBuffer buffer, int length) {
        String value = "";
        for (int i = 0; i < length; i++) {
            value += String.format("%02X ", buffer.get());
        }
        return value.trim();
    }

    /**
     * print buffer in hex String
     * @param buffer
     * @param length
     * @return
     */
    static public String toHexString(ByteBuffer buffer, int startPos, int length) {
        buffer.position(startPos);
        return toHexString(buffer, length);
    }
}
