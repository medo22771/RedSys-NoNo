package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;
import java.util.Calendar;

public class Msg0050 extends Msg {

    public static final String ID = "0050";

    private static final int MSG0050_DRAWER = 8;
    private static final int MSG0050_digits_of_the_pan= 10;
    private static final int MSG0050_SEPARATOR_OFF= 22;
    private static final int MSG0050_PROPRIETARY_DATA_LENGTH_OFF = 23;
    private static final int MSG0050_PROPRIETARY_DATA_OFF = 26;

    private static final int MSG0050_MSG0050_DRAWER_SIZE = 2;
    private static final int MSG0050_digits_of_the_pan_SIZE = 12;



    private String Drawer;
    private String digits_of_the_pan;

    public Msg0050(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        Drawer = (new String(data, MSG0050_DRAWER, MSG0050_MSG0050_DRAWER_SIZE));
        digits_of_the_pan = (new String(data, MSG0050_digits_of_the_pan, MSG0050_digits_of_the_pan_SIZE));
        setProprietaryData(data, MSG0050_PROPRIETARY_DATA_LENGTH_OFF);

    }

    public void setDrawer(String drawer) {
        Drawer = drawer;
    }

    public void setDigits_of_the_pan(String digits_of_the_pan) {
        this.digits_of_the_pan = digits_of_the_pan;
    }

}
