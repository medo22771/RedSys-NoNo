package com.yelloco.redsys.pup;

import java.text.DecimalFormat;

public class Msg0101 extends Msg {

    public static final String ID = "0101";

    private static int LBIN=0;
    private static int card_bin;
    private static short track_enc;
    private static short identifier_of_key  ;
    private static int LRESPA = 0;
    private static String response_to_authorization;
    private static int estado;
    private static String terminal_action_code;
    private static String random_num_for_suffering_class;
    private static String separator;
    private static int type_of_info;
    private static int signature_length;
    private static int scanned_signature;






    private static final int Msg0101_LBIN= 8;
    private static final int Msg0101_CARD_BIN= 10;
    private static int Msg0101_TRACK_ENCRYPTION= 10+LBIN;
    private static int Msg0101_IDENTIFIER_OF_THE_KEY= 11+LBIN;
    private static int Msg0101_LRESPA= 12+LBIN;
    private static int Msg0101_RESPONSE_TO_AUTHORIZATION= 16+LBIN;
    private static int Msg0101_ESTADO= 16+LBIN+LRESPA;
    private static int Msg0101_TERMINAL_ACTION_CODE= 20+LBIN+LRESPA;
    private static int Msg0101_RANDOM_NUM_FOR_CIPHERING_CLASS= 50+LBIN+LRESPA;
    private static int Msg0101_SEPARATOR= 56+LBIN+LRESPA;
    private static int Msg0101_TYPE_OF_INFORMATION= 57+LBIN+LRESPA;
    private static int Msg0101_SIGNATURE_LENGTH=61+LBIN+LRESPA;
    private static int Msg0101_SCANNED_SIGNATURE= 65+LBIN+LRESPA;


    private static final int MSG0101_SEPARATOR_OFF= 65+LBIN+LRESPA+signature_length;
    private static int MSG0101_PROPRIETARY_DATA_LENGTH_OFF = 66+LBIN+LRESPA+signature_length;
    private static final int MS0101_PROPRIETARY_DATA_OFF = 69+LBIN+LRESPA+signature_length;

    private static final int Msg0101_LBIN_SIZE= 2;
    private static int Msg0101_CARD_BIN_SIZE= LBIN;
    private static final int Msg0101_TRACK_ENCRYPTION_SIZE= 1;
    private static final int Msg0101_IDENTIFIER_OF_THE_KEY_SIZE= 1;
    private static final int Msg0101_LRESPA_SIZE= 4;
    private static int Msg0101_RESPONSE_TO_AUTHORIZATION_SIZE= LRESPA;
    private static final int Msg0101_ESTADO_SIZE= 4;
    private static final int Msg0101_TERMINAL_ACTION_CODE_SIZE= 30;
    private static final int Msg0101_RANDOM_NUM_FOR_CIPHERING_CLASS_SIZE= 6;
    private static final int Msg0101_SEPARATOR_SIZE= 1;
    private static final int Msg0101_TYPE_OF_INFORMATION_SIZE= 4;
    private static final int Msg0101_SIGNATURE_LENGTH_SIZE= 4;
    private static int Msg0101_SCANNED_SIGNATURE_SIZE= signature_length;






    public Msg0101(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
        int ahmed = 0;

    }


    public void fromPupMessage(byte[] data) {
        LBIN = Integer.parseInt(new String(data, Msg0101_LBIN, Msg0101_LBIN_SIZE));
        Msg0101_CARD_BIN_SIZE= LBIN;
        card_bin = Integer.parseInt(new String(data, Msg0101_CARD_BIN, Msg0101_CARD_BIN_SIZE));
        Msg0101_TRACK_ENCRYPTION= 10+LBIN;
        track_enc = (short) Integer.parseInt(new String(data, Msg0101_TRACK_ENCRYPTION, Msg0101_TRACK_ENCRYPTION_SIZE));
        Msg0101_IDENTIFIER_OF_THE_KEY= 11+LBIN;
        identifier_of_key = (short) Integer.parseInt(new String(data, Msg0101_IDENTIFIER_OF_THE_KEY, Msg0101_IDENTIFIER_OF_THE_KEY_SIZE));
        Msg0101_LRESPA= 12+LBIN;
        LRESPA = Integer.parseInt(new String(data, Msg0101_LRESPA, Msg0101_LRESPA_SIZE));
        Msg0101_RESPONSE_TO_AUTHORIZATION= 16+LBIN;
        Msg0101_RESPONSE_TO_AUTHORIZATION_SIZE= LRESPA;
        response_to_authorization = String.valueOf(new String(data, Msg0101_RESPONSE_TO_AUTHORIZATION, Msg0101_RESPONSE_TO_AUTHORIZATION_SIZE));
        Msg0101_ESTADO= 16+LBIN+LRESPA;
        estado = Integer.parseInt(new String(data, Msg0101_ESTADO, Msg0101_ESTADO_SIZE));
        Msg0101_TERMINAL_ACTION_CODE= 20+LBIN+LRESPA;
        terminal_action_code = String.valueOf(new String(data, Msg0101_TERMINAL_ACTION_CODE, Msg0101_TERMINAL_ACTION_CODE_SIZE));
        Msg0101_RANDOM_NUM_FOR_CIPHERING_CLASS= 50+LBIN+LRESPA;
        random_num_for_suffering_class = String.valueOf(new String(data, Msg0101_RANDOM_NUM_FOR_CIPHERING_CLASS, Msg0101_RANDOM_NUM_FOR_CIPHERING_CLASS_SIZE));
        Msg0101_SEPARATOR= 56+LBIN+LRESPA;
        separator = (new String(data, Msg0101_SEPARATOR, Msg0101_SEPARATOR_SIZE));
        Msg0101_TYPE_OF_INFORMATION= 57+LBIN+LRESPA;
        type_of_info = Integer.parseInt(new String(data, Msg0101_TYPE_OF_INFORMATION, Msg0101_TYPE_OF_INFORMATION_SIZE));
        Msg0101_SIGNATURE_LENGTH=61+LBIN+LRESPA;
        signature_length = Integer.parseInt(new String(data, Msg0101_SIGNATURE_LENGTH, Msg0101_SIGNATURE_LENGTH_SIZE));
        Msg0101_SCANNED_SIGNATURE= 65+LBIN+LRESPA;
        Msg0101_SCANNED_SIGNATURE_SIZE= signature_length;
        scanned_signature = Integer.parseInt(new String(data, Msg0101_SCANNED_SIGNATURE, Msg0101_SCANNED_SIGNATURE_SIZE));
        MSG0101_PROPRIETARY_DATA_LENGTH_OFF = 66+LBIN+LRESPA+signature_length;
        setProprietaryData(data, MSG0101_PROPRIETARY_DATA_LENGTH_OFF);
    }
    
}
