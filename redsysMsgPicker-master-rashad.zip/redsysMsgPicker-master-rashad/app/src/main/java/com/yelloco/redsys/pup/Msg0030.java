package com.yelloco.redsys.pup;

import com.yelloco.redsys.pup.Msg;

public class Msg0030 extends Msg {


    public static final String ID = "0030";

    private static final int MSG0030_SIGNATURE_APPLICATION= 8;
    private static final int MSG0030_SEPARATOR_OFF= 12;
    private static final int MSG0030_PROPRIETARY_DATA_LENGTH_OFF = 13;
    private static final int MS0030_PROPRIETARY_DATA_OFF = 16;

    private static final int Msg0030_SIGNATURE_APPLICATION_SIZE = 4;

    private int signature_app;

    public Msg0030(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        signature_app = Integer.parseInt(new String(data, MSG0030_SIGNATURE_APPLICATION, Msg0030_SIGNATURE_APPLICATION_SIZE));
        setProprietaryData(data, MSG0030_PROPRIETARY_DATA_LENGTH_OFF);
    }

    public void setCONFIRMATION_ANSWER(int readingState) {
        signature_app = readingState;
    }



}
