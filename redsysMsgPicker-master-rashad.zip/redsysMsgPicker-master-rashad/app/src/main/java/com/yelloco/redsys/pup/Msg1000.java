package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Msg1000 extends Msg {

    public static final String ID = "1000";

    private static final int MSG1000_AMOUNT_OF_TRANSACTION = 8;
    private static final int MSG1000_TABLE_FOR_RISK_CONTROL= 18;
    private static final int MSG1000_DRAWER = 20;

    private static final int MSG1000_SEPARATOR_OFF= 22;
    private static final int MSG1000_PROPRIETARY_DATA_LENGTH_OFF = 23;
    private static final int MSG1000_PROPRIETARY_DATA_OFF = 26;

    private static final int MSG1000_AMOUNT_OF_THE_TRANSACTION_SIZE = 10;
    private static final int MSG1000_TABLE_FOR_RISK_CONTROL_SIZE = 2;
    private static final int MSG1000_MSG1000_DRAWER_SIZE = 2;


    private int transactionamount;
    private int RiskControle_table;
    private String Drawer;

    public Msg1000(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        transactionamount = Integer.parseInt(new String(data, MSG1000_AMOUNT_OF_TRANSACTION, MSG1000_AMOUNT_OF_THE_TRANSACTION_SIZE));
        RiskControle_table = Integer.parseInt(new String(data, MSG1000_TABLE_FOR_RISK_CONTROL, MSG1000_TABLE_FOR_RISK_CONTROL_SIZE));
        Drawer = String.valueOf(Integer.parseInt(new String(data, MSG1000_DRAWER, MSG1000_MSG1000_DRAWER_SIZE)));
        setProprietaryData(data, MSG1000_PROPRIETARY_DATA_LENGTH_OFF);

    }

    public void setTransactionamount(int transactionamount) {
        this.transactionamount = transactionamount;
    }

    public void setRiskControle_table(int riskControle_table) {
        RiskControle_table = riskControle_table;
    }

    public void setDrawer(String drawer) {
        Drawer = drawer;
    }
}
