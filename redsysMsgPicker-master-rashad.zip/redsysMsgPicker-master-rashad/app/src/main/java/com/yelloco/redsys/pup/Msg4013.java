package com.yelloco.redsys.pup;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;

public class Msg4013 extends Msg {

    public static final String ID = "4013";

    private static final int MSG4013_END_OF_DOWNLOAD_CONFIRMATION = 8;
    private static final int MSG4013_SEPARATOR_OFF= 9;
    private static final int MSG4013_PROPRIETARY_DATA_LENGTH_OFF = 10;
    private static final int MSG4013_PROPRIETARY_DATA_OFF = 13;

    private static final int Msg4013_END_OF_DOWNLOAD_CONFIRMATION_SIZE = 1;

    private static short download_process_end;
    private static short deskNumber;
    private static byte pciScenario;

//    public Msg4013(byte[] data, int length) {
//        super(data, length);
//        fromPupMessage(data);
//    }
//
//    public void fromPupMessage(byte[] data) {
//        download_process_end = (short) Integer.parseInt(new String(data, MSG4013_END_OF_DOWNLOAD_CONFIRMATION, Msg4013_END_OF_DOWNLOAD_CONFIRMATION_SIZE));
//        setProprietaryData(data, MSG4013_PROPRIETARY_DATA_LENGTH_OFF);
//    }


    public void fillForTesting() {
        setDownload_process_end((short) 1);
    }


    public static byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, MSG4013_END_OF_DOWNLOAD_CONFIRMATION, String.format("%01d", download_process_end).getBytes(), Msg4013_END_OF_DOWNLOAD_CONFIRMATION_SIZE);
        if (deskNumber > 0) {
            // not happen yet
        }
        buffer.put(pciScenario);

        buffer.put(MSG_SEPARATOR);
        BufferUtil.put(buffer, String.format("%03d", getProprietaryDataLength()).getBytes(), 0, MSG_PROPRIETARY_DATA_LENGTH_SIZE);
        int dataLength = buffer.position();

        // setLength of the buffer
        BufferUtil.put(buffer, MSG_LENGTH_FIELD_OFF, String.format("%04d", dataLength).getBytes());
        setLength(dataLength);

        return data;
    }

    public static void setDownload_process_end(short download_process_end) {
        Msg4013.download_process_end = download_process_end;
    }
}
