package com.yelloco.redsys.pup;

public class Msg4003 extends Msg {

    public static final String ID = "4003";

    private static final int MSG4003_END_OF_DOWNLOAD_PROCESS = 8;
    private static final int MSG4003_SEPARATOR_OFF= 9;
    private static final int MSG4003_PROPRIETARY_DATA_LENGTH_OFF = 10;
    private static final int MS4003_PROPRIETARY_DATA_OFF = 13;

    private static final int Msg4003_END_OF_DOWNLOAD_PROCESS_SIZE = 1;

    private short download_process_end;

    public Msg4003(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        download_process_end = (short) Integer.parseInt(new String(data, MSG4003_END_OF_DOWNLOAD_PROCESS, Msg4003_END_OF_DOWNLOAD_PROCESS_SIZE));
        setProprietaryData(data, MSG4003_PROPRIETARY_DATA_LENGTH_OFF);
    }


}
