package com.yelloco.redsys.pup;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;
import java.util.Calendar;

public class Msg0060 extends Msg {

    public static final String ID = "0060";

    private static final int MSG0060_TYPE_OF_INFORMATION = 8;
    private static final int MSG0060_ZONE_INDEX_OF_THE_PIN_KEY= 14;
    private static final int MSG0060_NUMBER_DIGITS_OF_TYPE_PIN = 16;
    private static final int MSG0060_DRAWER_USED_BY_THE_PIN_PAD= 17;

    private static final int MSG0060_SEPARATOR_OFF= 19;
    private static final int MSG0060_PROPRIETARY_DATA_LENGTH_OFF = 20;
    private static final int MSG0060_PROPRIETARY_DATA_OFF = 23;

    private static final int MSG0060_TYPE_OF_INFORMATION_SIZE = 6;
    private static final int MSG0060_ZONE_INDEX_OF_THE_PIN_KEY_SIZE = 2;
    private static final int MSG0060_NUMBER_DIGITS_OF_TYPE_PIN_SIZE = 1;
    private static final int MSG0060_DRAWER_USED_BY_THE_PIN_PAD_SIZE = 2;


    private static int informayion_type;
    private static int zone_index_of_pin_key;
    private static char digits_number_pin;
    private static String drawer_used;
    private static short deskNumber;
    private static byte pciScenario;

//    public Msg0060(byte[] data, int length) {
//        super(data, length);
//        fromPupMessage(data);
//    }
//
//    public void fromPupMessage(byte[] data) {
//        ByteBuffer buffer = ByteBuffer.wrap(data);
//        informayion_type = Integer.parseInt(new String(data, MSG0060_TYPE_OF_INFORMATION, MSG0060_TYPE_OF_INFORMATION_SIZE));
//        zone_index_of_pin_key = Integer.parseInt(new String(data, MSG0060_ZONE_INDEX_OF_THE_PIN_KEY, MSG0060_ZONE_INDEX_OF_THE_PIN_KEY_SIZE));
//        digits_number_pin = Integer.parseInt(new String(data, MSG0060_NUMBER_DIGITS_OF_TYPE_PIN, MSG0060_NUMBER_DIGITS_OF_TYPE_PIN_SIZE));
//        drawer_used = Integer.parseInt(new String(data, MSG0060_DRAWER_USED_BY_THE_PIN_PAD, MSG0060_DRAWER_USED_BY_THE_PIN_PAD_SIZE));
//        setProprietaryData(data, MSG0060_PROPRIETARY_DATA_LENGTH_OFF);
//
//    }


    public void fillForTesting() {
        setInformayion_type(0001);
        setZone_index_of_pin_key(01);
        setDigits_number_pin('4');
        setDrawer_used("01");

    }



    public static byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, MSG0060_TYPE_OF_INFORMATION, String.format("%06d", informayion_type).getBytes(), MSG0060_TYPE_OF_INFORMATION_SIZE);
        BufferUtil.put(buffer, MSG0060_ZONE_INDEX_OF_THE_PIN_KEY, String.format("%02d", zone_index_of_pin_key).getBytes(), MSG0060_ZONE_INDEX_OF_THE_PIN_KEY_SIZE);
        BufferUtil.put(buffer, MSG0060_NUMBER_DIGITS_OF_TYPE_PIN, String.format("%01d", digits_number_pin).getBytes(), MSG0060_NUMBER_DIGITS_OF_TYPE_PIN_SIZE);
        BufferUtil.put(buffer, MSG0060_DRAWER_USED_BY_THE_PIN_PAD, String.format("%02d", drawer_used).getBytes(), MSG0060_DRAWER_USED_BY_THE_PIN_PAD_SIZE);
        if (deskNumber > 0) {
            // not happen yet
        }
        buffer.put(pciScenario);

        buffer.put(MSG_SEPARATOR);
        BufferUtil.put(buffer, String.format("%03d", getProprietaryDataLength()).getBytes(), 0, MSG_PROPRIETARY_DATA_LENGTH_SIZE);
        int dataLength = buffer.position();

        // setLength of the buffer
        BufferUtil.put(buffer, MSG_LENGTH_FIELD_OFF, String.format("%04d", dataLength).getBytes());
        setLength(dataLength);

        return data;
    }


    public void setInformayion_type(int informayion_type) {
        this.informayion_type = informayion_type;
    }

    public void setZone_index_of_pin_key(int zone_index_of_pin_key) {
        this.zone_index_of_pin_key = zone_index_of_pin_key;
    }

    public void setDigits_number_pin(char digits_number_pin) {
        this.digits_number_pin = digits_number_pin;
    }

    public void setDrawer_used(String drawer_used) {
        this.drawer_used = drawer_used;
    }
}
