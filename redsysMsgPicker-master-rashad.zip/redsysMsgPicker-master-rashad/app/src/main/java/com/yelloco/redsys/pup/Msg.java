package com.yelloco.redsys.pup;

/**
 * Created by trnguyen on 03/04/18.
 */

public class Msg {
    public static final int MSG_ID_FIELD_OFF = 0;
    public static final int MSG_LENGTH_FIELD_OFF= 4;

    public static final int MSG_ID_FIELD_SIZE = 4;
    public static final int MSG_LENGTH_FIELD_SIZE = 4;
    public static final int MSG_SEPARATOR_SIZE = 1;
    public static final int MSG_PROPRIETARY_DATA_LENGTH_SIZE = 3;

    public static final byte MSG_SEPARATOR = '@';
    public static final int MSG_MAX_SIZE = 1024;

    private String id;
    private static int length = 0;
    private static int proprietaryDataLength = 0;
    private byte[] proprietaryData;

    public Msg() {
    }

    public Msg(byte[] data, int length) {
        id = new String(data, MSG_ID_FIELD_OFF, MSG_ID_FIELD_SIZE);
        this.length = Integer.parseInt(new String(data, MSG_LENGTH_FIELD_OFF, MSG_LENGTH_FIELD_SIZE));
    }

    public String getId() {
        return id;
    }

    public static int getLength() {
        return length;
    }

    public static void setLength(int length) {
        Msg.length = length;
    }

    public static int getProprietaryDataLength() {
        return proprietaryDataLength;
    }

    public byte[] getProprietaryData() {
        return proprietaryData;
    }

    public void setProprietaryData(byte[] data, int proprietaryDataLengthOffset) {
        proprietaryDataLength = Integer.parseInt(new String(data, proprietaryDataLengthOffset, MSG_PROPRIETARY_DATA_LENGTH_SIZE));
        if (proprietaryDataLength > 0) {
            proprietaryData = new byte[proprietaryDataLength];
            System.arraycopy(data, proprietaryDataLengthOffset + MSG_PROPRIETARY_DATA_LENGTH_SIZE, proprietaryData, 0, proprietaryDataLength);
        }
    }
}
