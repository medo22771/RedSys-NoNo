package com.yelloco.redsys.pup;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;

public class Msg4012 extends Msg {


    public static final String ID = "4012";

    private static final int MSG4012_STATE = 8;
    private static final int MSG4012_SOFTWARE_PRO_NAME= 10;
    private static final int MSG4012_SOFTWARE_PRO_VERSION = 18;
    private static final int MSG4012_BLOCK_NUMBER= 22;

    private static final int MSG4012_SEPARATOR_OFF= 25;
    private static final int MSG4012_PROPRIETARY_DATA_LENGTH_OFF = 26;
    private static final int MSG4012_PROPRIETARY_DATA_OFF = 29;

    private static final int MSG4012_STATE_SIZE = 2;
    private static final int MSG4012_SOFTWARE_PRO_NAME_SIZE = 8;
    private static final int MSG4012_SOFTWARE_PRO_VERSION_SIZE = 4;
    private static final int MSG4012_BLOCK_NUMBER_SIZE = 3;


    private static Short STATE;
    private static String pro_name;
    private static String  pro_version;
    private static short block_number;
    private static short deskNumber;
    private static byte pciScenario;


//    public Msg4012(byte[] data, int length) {
//        super(data, length);
//        fromPupMessage(data);
//    }
//
//    public void fromPupMessage(byte[] data) {
//        ByteBuffer buffer = ByteBuffer.wrap(data);
//        STATE = (short)Integer.parseInt(new String(data, MSG4012_STATE, MSG4012_STATE_SIZE));
//        pro_name = (new String(data, MSG4012_SOFTWARE_PRO_NAME, MSG4012_SOFTWARE_PRO_NAME_SIZE));
//        pro_version = (new String(data, MSG4012_SOFTWARE_PRO_VERSION, MSG4012_SOFTWARE_PRO_VERSION_SIZE));
//        block_number = (short) Integer.parseInt(new String(data, MSG4012_BLOCK_NUMBER, MSG4012_BLOCK_NUMBER_SIZE));
//        setProprietaryData(data, MSG4012_PROPRIETARY_DATA_LENGTH_OFF);
//
//    }

    public void fillForTesting() {
        setSTATE((short) 0001);
        setPro_name("10000010");
        setPro_version("0001");
        setBlock_number((short) 001);
    }


    public static byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, MSG4012_STATE, String.format("%02d", STATE).getBytes(), MSG4012_STATE_SIZE);
        BufferUtil.put(buffer, MSG4012_SOFTWARE_PRO_NAME, pro_name.getBytes(), MSG4012_SOFTWARE_PRO_NAME_SIZE);
        BufferUtil.put(buffer, MSG4012_SOFTWARE_PRO_VERSION, pro_version.getBytes(), MSG4012_SOFTWARE_PRO_VERSION_SIZE);
        BufferUtil.put(buffer, MSG4012_BLOCK_NUMBER, String.format("%03d", block_number).getBytes(), MSG4012_BLOCK_NUMBER_SIZE);

        if (deskNumber > 0) {
            // not happen yet
        }
        buffer.put(pciScenario);

        buffer.put(MSG_SEPARATOR);
        BufferUtil.put(buffer, String.format("%03d", getProprietaryDataLength()).getBytes(), 0, MSG_PROPRIETARY_DATA_LENGTH_SIZE);
        int dataLength = buffer.position();

        // setLength of the buffer
        BufferUtil.put(buffer, MSG_LENGTH_FIELD_OFF, String.format("%04d", dataLength).getBytes());
        setLength(dataLength);

        return data;
    }

    public static void setSTATE(Short STATE) {
        Msg4012.STATE = STATE;
    }

    public static void setPro_name(String pro_name) {
        Msg4012.pro_name = pro_name;
    }

    public static void setPro_version(String pro_version) {
        Msg4012.pro_version = pro_version;
    }

    public static void setBlock_number(short block_number) {
        Msg4012.block_number = block_number;
    }
}
