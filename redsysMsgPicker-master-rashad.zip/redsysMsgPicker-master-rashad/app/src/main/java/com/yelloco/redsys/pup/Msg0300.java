package com.yelloco.redsys.pup;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;

/**
 * Created by Desktop 10 on 4/12/2018.
 */

public class Msg0300 extends Msg {


    public static final String ID = "0300";




    private static short FLAG_CONTROL;
    private short REST_RESULT_OF_CHIP_ATTEMPT;
    private short EXPIRED_CARD;
    private short CARD_TYPE_INDICATOR;
    private static short LBIN=0;
    private String BIN_OF_THE_CARD;
    private String SERVICE_CODE;
    private short TRACK_ENCRYPTION;
    private short IDENTIFIER_OF_THE_KEY;
    private static int LIPSTA2=0;
    private String READING_TRACK2;
    private String ESTADO;
    private short RANDOM_NUMBER_OF_TRACK_ENCRYPTION;
    private String AID;
    private static short deskNumber;
    private static byte pciScenario;





    private static final int MSG0300_FLAG_CONTROL = 8;
    private static final int MSG0300_REST_RESULT_OF_CHIP_ATTEMPT= 9;
    private static final int MSG0300_EXPIRED_CARD = 10;
    private static final int MSG0300_CARD_TYPE_INDICATOR = 11;
    private static final int MSG0300_LBIN= 12;
    private static final int MSG0300_BIN_OF_THE_CARD = 14;
    private static final int MSG0300_SERVICE_CODE = 14+LBIN;
    private static final int MSG0300_TRACK_ENCRYPTION = 17+LBIN;
    private static final int MSG0300_IDENTIFIER_OF_THE_KEY = 18+LBIN;
    private static final int MSG0300_LPISTA2 = 19+LBIN;
    private static final int MSG0300_READING_TRACK2= 23+LBIN;
    private static final int MSG0300_ESTADO = 23+LBIN+LIPSTA2;
    private static final int MSG0300_RANDOM_NUMBER_OF_TRACK_ENCRYPTION = 27+LBIN+LIPSTA2;
    private static final int MSG0300_AID = 33+LBIN+LIPSTA2;

    private static final int MSG0300_SEPARATOR_OFF= 47+LBIN+LIPSTA2;
    private static final int MSG0300_PROPRIETARY_DATA_LENGTH_OFF = 48+LBIN+LIPSTA2;
    private static final int MS0300_PROPRIETARY_DATA_OFF = 51+LBIN+LIPSTA2;





    private static final int MSG0300_FLAG_CONTROL_SIZE = 1;
    private static final int MSG0300_LAST_RESULT_OF_CHIP_ATTEMPT_SIZE = 1;
    private static final int MSG0300_EXPIRED_CARD_SIZE = 1;
    private static final int MSG0300_CARD_TYPE_INDICATOR_SIZE = 1;
    private static final int MSG0300_LBIN_SIZE = 2;
    private static final int MSG0300_BIN_OF_THE_CARD_SIZE = LBIN;
    private static final int MSG0300_SERVICE_CODE_SIZE = 3;
    private static final int MSG0300_TRACK_ENCRYPTION_SIZE = 1;
    private static final int MSG0300_IDENTIFIER_OF_THE_KEY_SIZE = 1;
    private static final int MSG0300_LPISTA2_SIZE = 4;
    private static final int MSG0300_READING_TRACK2_SIZE = LIPSTA2;
    private static final int MSG0300_ESTADO_SIZE = 4;
    private static final int MSG0300_RANDOM_NUMBER_OF_TRACK_ENCRYPTION_SIZE = 6;
    private static final int MSG0300_AID_SIZE = 14;

    public Msg0300(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        FLAG_CONTROL = (short) Integer.parseInt(new String(data, MSG0300_FLAG_CONTROL, MSG0300_FLAG_CONTROL_SIZE));
        REST_RESULT_OF_CHIP_ATTEMPT = (short) Integer.parseInt(new String(data, MSG0300_REST_RESULT_OF_CHIP_ATTEMPT, MSG0300_LAST_RESULT_OF_CHIP_ATTEMPT_SIZE));
        EXPIRED_CARD = (short) Integer.parseInt(new String(data, MSG0300_EXPIRED_CARD, MSG0300_EXPIRED_CARD_SIZE));
        CARD_TYPE_INDICATOR = (short) Integer.parseInt(new String(data, MSG0300_CARD_TYPE_INDICATOR, MSG0300_CARD_TYPE_INDICATOR_SIZE));
        LBIN = (short) Integer.parseInt(new String(data, MSG0300_LBIN, MSG0300_LBIN_SIZE));
        BIN_OF_THE_CARD = (new String(data, MSG0300_BIN_OF_THE_CARD, MSG0300_BIN_OF_THE_CARD_SIZE));
        SERVICE_CODE = (new String(data, MSG0300_SERVICE_CODE, MSG0300_SERVICE_CODE_SIZE));
        TRACK_ENCRYPTION = (short) Integer.parseInt(new String(data, MSG0300_TRACK_ENCRYPTION, MSG0300_TRACK_ENCRYPTION_SIZE));
        IDENTIFIER_OF_THE_KEY = (short) Integer.parseInt(new String(data, MSG0300_IDENTIFIER_OF_THE_KEY, MSG0300_IDENTIFIER_OF_THE_KEY_SIZE));
        LIPSTA2 = Integer.parseInt(new String(data, MSG0300_LPISTA2, MSG0300_LPISTA2_SIZE));
        READING_TRACK2 = String.valueOf(new String(data, MSG0300_READING_TRACK2, MSG0300_READING_TRACK2_SIZE));
        ESTADO = (new String(data, MSG0300_ESTADO, MSG0300_ESTADO_SIZE));
        RANDOM_NUMBER_OF_TRACK_ENCRYPTION = Short.parseShort(new String(data, MSG0300_RANDOM_NUMBER_OF_TRACK_ENCRYPTION, MSG0300_RANDOM_NUMBER_OF_TRACK_ENCRYPTION_SIZE));
        AID = (new String(data, MSG0300_AID, MSG0300_AID_SIZE));
        setProprietaryData(data, MSG0300_PROPRIETARY_DATA_LENGTH_OFF);
    }

}
