package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;

public class Msg4001 extends Msg {


    public static final String ID = "4001";

    private static final int MSG4001_STARTUP_DOWNLOAD_REQUEST = 8;
    private static final int MSG4001_NAME_PROGRAM_TO_DOWNLOAD= 9;
    private static final int MSG4001_PROGRAM_VERSION_TO_DOWNLOAD = 17;
    private static final int MSG4001_DOWNLOAD_FILE= 21;
    private static final int MSG4001_TOTAL_FILES_TO_DOWNLOAD= 23;

    private static final int MSG4001_SEPARATOR_OFF= 25;
    private static final int MSG4001_PROPRIETARY_DATA_LENGTH_OFF = 26;
    private static final int MSG4001_PROPRIETARY_DATA_OFF = 29;

    private static final int MSG4001_STARTUP_DOWNLOAD_REQUEST_SIZE = 1;
    private static final int MSG4001_NAME_PROGRAM_TO_DOWNLOAD_SIZE = 8;
    private static final int MSG4001_PROGRAM_VERSION_TO_DOWNLOAD_SIZE = 4;
    private static final int MSG4001_DOWNLOAD_FILE_SIZE = 2;
    private static final int MSG4001_TOTAL_FILES_TO_DOWNLOAD_SIZE = 2;


    private short downloadrequest;
    private String nameofprogram;
    private String programversion;
    private short Downloadfile;
    private short totalfiles;

    public Msg4001(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        downloadrequest = (short) Integer.parseInt(new String(data, MSG4001_STARTUP_DOWNLOAD_REQUEST, MSG4001_STARTUP_DOWNLOAD_REQUEST_SIZE));
        nameofprogram = (new String(data, MSG4001_NAME_PROGRAM_TO_DOWNLOAD, MSG4001_NAME_PROGRAM_TO_DOWNLOAD_SIZE));
        programversion = (new String(data, MSG4001_PROGRAM_VERSION_TO_DOWNLOAD, MSG4001_PROGRAM_VERSION_TO_DOWNLOAD_SIZE));
        Downloadfile = (short) Integer.parseInt(new String(data, MSG4001_DOWNLOAD_FILE, MSG4001_DOWNLOAD_FILE_SIZE));
        totalfiles = (short) Integer.parseInt(new String(data, MSG4001_TOTAL_FILES_TO_DOWNLOAD, MSG4001_TOTAL_FILES_TO_DOWNLOAD_SIZE));
        setProprietaryData(data, MSG4001_PROPRIETARY_DATA_LENGTH_OFF);

    }



}
