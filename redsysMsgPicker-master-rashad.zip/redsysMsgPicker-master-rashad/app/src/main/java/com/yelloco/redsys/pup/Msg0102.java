package com.yelloco.redsys.pup;

public class Msg0102 extends Msg {


    public static final String ID = "0102";

    private static int LBIN=0;
    private static int card_bin=0;
    private static int track_enc = 0;
    private static int identifier_of_key =0 ;
    private static int LRESPA = 0;
    private static String response_to_authorization;
    private static int estado =0 ;
    private static String terminal_action_code;
    private static String random_num_for_suffering_class;
    private static int separator =0 ;
    private static int signature_length = 0;
    private static int scanned_signature =0 ;




    private static final int Msg0102_LBIN= 8;
    private static final int Msg0102_CARD_BIN= 10;
    private static int Msg0102_TRACK_ENCRYPTION= 10+LBIN;
    private static int Msg0102_IDENTIFIER_OF_THE_KEY= 11+LBIN;
    private static int Msg0102_LRESPA= 12+LBIN;
    private static int Msg0102_RESPONSE_TO_AUTHORIZATION= 16+LBIN;
    private static int Msg0102_ESTADO= 16+LBIN+LRESPA;
    private static int Msg0102_TERMINAL_ACTION_CODE= 20+LBIN+LRESPA;
    private static int Msg0102_RANDOM_NUM_FOR_CIPHERING_CLASS= 50+LBIN+LRESPA;
    private static int Msg0102_SEPARATOR= 56+LBIN+LRESPA;
    private static int Msg0102_SIGNATURE_LENGTH= 57+LBIN+LRESPA;
    private static int Msg0102_SCANNED_SIGNATURE= 61+LBIN+LRESPA;



    private static final int MSG0102_SEPARATOR_OFF= 61+LBIN+LRESPA+signature_length;
    private static int MSG0102_PROPRIETARY_DATA_LENGTH_OFF = 62+LBIN+LRESPA+signature_length;
    private static final int MS0102_PROPRIETARY_DATA_OFF = 65+LBIN+LRESPA+signature_length;




    private static final int Msg0102_LBIN_SIZE= 2;
    private static int Msg0102_CARD_BIN_SIZE= LBIN;
    private static final int Msg0102_TRACK_ENCRYPTION_SIZE= 1;
    private static final int Msg0102_IDENTIFIER_OF_THE_KEY_SIZE= 1;
    private static final int Msg0102_LRESPA_SIZE= 4;
    private static int Msg0102_RESPONSE_TO_AUTHORIZATION_SIZE= LRESPA;
    private static final int Msg0102_ESTADO_SIZE= 4;
    private static final int Msg0102_TERMINAL_ACTION_CODE_SIZE= 30;
    private static final int Msg0102_RANDOM_NUM_FOR_CIPHERING_CLASS_SIZE= 6;
    private static final int Msg0102_SEPARATOR_SIZE= 1;
    private static final int Msg0102_SIGNATURE_LENGTH_SIZE= 4;
    private static int Msg0102_SCANNED_SIGNATURE_SIZE= signature_length;




    public Msg0102(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        LBIN = Integer.parseInt(new String(data, Msg0102_LBIN, Msg0102_LBIN_SIZE));
        Msg0102_CARD_BIN_SIZE= LBIN;
        card_bin = Integer.parseInt(new String(data, Msg0102_CARD_BIN, Msg0102_CARD_BIN_SIZE));
        Msg0102_TRACK_ENCRYPTION= 10+LBIN;
        track_enc = Integer.parseInt(new String(data, Msg0102_TRACK_ENCRYPTION, Msg0102_TRACK_ENCRYPTION_SIZE));
        Msg0102_IDENTIFIER_OF_THE_KEY= 11+LBIN;
        identifier_of_key = Integer.parseInt(new String(data, Msg0102_IDENTIFIER_OF_THE_KEY, Msg0102_IDENTIFIER_OF_THE_KEY_SIZE));
        Msg0102_LRESPA= 12+LBIN;
        LRESPA = Integer.parseInt(new String(data, Msg0102_LRESPA, Msg0102_LRESPA_SIZE));
        Msg0102_RESPONSE_TO_AUTHORIZATION= 16+LBIN;
        Msg0102_RESPONSE_TO_AUTHORIZATION_SIZE= LRESPA;
        response_to_authorization = (new String(data, Msg0102_RESPONSE_TO_AUTHORIZATION, Msg0102_RESPONSE_TO_AUTHORIZATION_SIZE));
        Msg0102_ESTADO= 16+LBIN+LRESPA;
        estado = Integer.parseInt(new String(data, Msg0102_ESTADO, Msg0102_ESTADO_SIZE));
        Msg0102_TERMINAL_ACTION_CODE= 20+LBIN+LRESPA;
        terminal_action_code = (new String(data, Msg0102_TERMINAL_ACTION_CODE, Msg0102_TERMINAL_ACTION_CODE_SIZE));
        Msg0102_RANDOM_NUM_FOR_CIPHERING_CLASS= 50+LBIN+LRESPA;
        random_num_for_suffering_class = (new String(data, Msg0102_RANDOM_NUM_FOR_CIPHERING_CLASS, Msg0102_RANDOM_NUM_FOR_CIPHERING_CLASS_SIZE));
        Msg0102_SEPARATOR= 56+LBIN+LRESPA;
        separator = Integer.parseInt(new String(data, Msg0102_SEPARATOR, Msg0102_SEPARATOR_SIZE));
        Msg0102_SIGNATURE_LENGTH= 57+LBIN+LRESPA;
        signature_length = Integer.parseInt(new String(data, Msg0102_SIGNATURE_LENGTH, Msg0102_SIGNATURE_LENGTH_SIZE));
        Msg0102_SCANNED_SIGNATURE= 61+LBIN+LRESPA;
        Msg0102_SCANNED_SIGNATURE_SIZE= signature_length;
        scanned_signature = Integer.parseInt(new String(data, Msg0102_SCANNED_SIGNATURE, Msg0102_SCANNED_SIGNATURE_SIZE));
        MSG0102_PROPRIETARY_DATA_LENGTH_OFF = 62+LBIN+LRESPA+signature_length;
        setProprietaryData(data, MSG0102_PROPRIETARY_DATA_LENGTH_OFF);
    }


}
