package com.yelloco.redsys;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.yelloco.redsys.pup.Msg;
import com.yelloco.redsys.pup.Msg0010;
import com.yelloco.redsys.pup.Msg0020;
import com.yelloco.redsys.pup.Msg0040;
import com.yelloco.redsys.pup.Msg0100;
import com.yelloco.redsys.pup.Msg0101;
import com.yelloco.redsys.pup.Msg0102;
import com.yelloco.redsys.pup.Msg0200;
import com.yelloco.redsys.pup.Msg1000;
import com.yelloco.redsys.pup.Msg1001;
import com.yelloco.redsys.pup.Msg2000;
import com.yelloco.redsys.pup.Msg2001;
import com.yelloco.redsys.pup.Msg2010;
import com.yelloco.redsys.pup.Msg2011;
import com.yelloco.redsys.pup.Msg4002;

public class MainActivity extends AppCompatActivity {
    EditText portText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Context context = getApplicationContext();
        SharedPreferences preferences = getApplicationContext().getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        Integer server_port = preferences.getInt(context.getString(R.string.port_ref), getResources().getInteger(R.integer.server_port));

        portText = findViewById(R.id.portText);
        portText.setText(server_port.toString());



    }

    public void startService(View view) {
        if (portText.getText().toString().isEmpty()) {
            portText.setError("Can't be empty");
            return;
        }

        Context context = getApplicationContext();
        SharedPreferences preferences = getApplicationContext().getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
        preferences.edit().putInt(context.getString(R.string.port_ref), Integer.parseInt(portText.getText().toString()));
        preferences.edit().apply();

        String s = "00040038003003000000080000000810030004";
        Msg4002 msg0200 = new Msg4002(s.getBytes(), 83);

//        Msg2011 msg2011 = new Msg2011();
//        msg2011.fillForTesting();
//        msg2011.toPupMessage();



        startService(new Intent(getBaseContext(), PinpadService.class));
        findViewById(R.id.startButton).setEnabled(false);
        findViewById(R.id.stopButton).setEnabled(true);
    }

    public void stopService(View view) {
        stopService(new Intent(getBaseContext(), PinpadService.class));
        findViewById(R.id.startButton).setEnabled(true);
        findViewById(R.id.stopButton).setEnabled(false);
    }
}
