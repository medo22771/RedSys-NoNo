package com.yelloco.redsys.pup;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;

public class Msg1012 extends Msg {

    public static final String ID = "1012";

    private static final int MSG1012_SELECTION_MADE = 8;

    private static final int Msg1012_SELECTION_MADE_SIZE = 2;

    private static short selectionmade;
    private static short deskNumber;
    private static byte pciScenario;
//    public Msg1012(byte[] data, int length) {
//        super(data, length);
//        fromPupMessage(data);
//    }
//
//    public void fromPupMessage(byte[] data) {
//        selectionmade = Integer.parseInt(new String(data, MSG1012_SELECTION_MADE, Msg1012_SELECTION_MADE_SIZE));
//    }

    public void fillForTesting() {
        setSelectionmade((short) 00);
    }


    public static byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, MSG1012_SELECTION_MADE, String.format("%02d", selectionmade).getBytes(), Msg1012_SELECTION_MADE_SIZE);
        if (deskNumber > 0) {
            // not happen yet
        }
        buffer.put(pciScenario);
        return data;
    }

    public static void setSelectionmade(short selectionmade) {
        Msg1012.selectionmade = selectionmade;
    }
}
