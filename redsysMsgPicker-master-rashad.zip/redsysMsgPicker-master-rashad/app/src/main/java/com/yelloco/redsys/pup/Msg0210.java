package com.yelloco.redsys.pup;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;

public class Msg0210 extends Msg {


    public static final String ID = "0210";

    private static final int Msg0210_MANUAL_ENTRY_CONFIRMATION= 8;
    private static final int MSG0210_SEPARATOR_OFF= 12;
    private static final int MSG0210_PROPRIETARY_DATA_LENGTH_OFF = 13;
    private static final int MS0210_PROPRIETARY_DATA_OFF = 16;

    private static final int Msg0210_MANUAL_ENTRY_CONFIRMATION_SIZE = 4;

    private static int manual_entry_confirmation;
    private static short deskNumber;
    private static byte pciScenario;


//    public Msg0210(byte[] data, int length) {
//        super(data, length);
//        fromPupMessage(data);
//    }
//
//    public void fromPupMessage(byte[] data) {
//        CONFIRMATION_ANSWER = Integer.parseInt(new String(data, Msg0210_CONFIRMATION_ANSWER, Msg0210_CONFIRMATION_ANSWER_SIZE));
//        setProprietaryData(data, MSG0210_PROPRIETARY_DATA_LENGTH_OFF);
//    }


    public void fillForTesting() {
        setManual_entry_confirmation(0001);
    }


    public static byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, Msg0210_MANUAL_ENTRY_CONFIRMATION, String.format("%04d", manual_entry_confirmation).getBytes(), Msg0210_MANUAL_ENTRY_CONFIRMATION_SIZE);
        if (deskNumber > 0) {
            // not happen yet
        }
        buffer.put(pciScenario);

        buffer.put(MSG_SEPARATOR);
        BufferUtil.put(buffer, String.format("%03d", getProprietaryDataLength()).getBytes(), 0, MSG_PROPRIETARY_DATA_LENGTH_SIZE);
        int dataLength = buffer.position();

        // setLength of the buffer
        BufferUtil.put(buffer, MSG_LENGTH_FIELD_OFF, String.format("%04d", dataLength).getBytes());
        setLength(dataLength);

        return data;
    }

    public void setManual_entry_confirmation(int manual_entry_confirmation) {
        this.manual_entry_confirmation = manual_entry_confirmation;
    }
}
