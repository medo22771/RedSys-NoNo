package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;

public class Msg0010 extends Msg {

    public static final String ID = "0010";




    private short FLAG_CONTROL;
    private short REST_RESULT_OF_CHIP_ATTEMPT;
    private short EXPIRED_CARD;
    private short CARD_TYPE_INDICATOR;
    private static int LBIN=0;
    private int BIN_OF_THE_CARD;
    private int SERVICE_CODE;
    private short TRACK_ENCRYPTION;
    private short IDENTIFIER_OF_THE_KEY;
    private static int LIPSTA1=0;
    private String READING_TRACK1;
    private static int LIPSTA2=0;
    private String READING_TRACK2;
    private String RANDOM_NUMBER_OF_TRACK_ENCRYPTION;
    private int ENCRYPTION_PIN_BLOCK;
    private int ZONE_INDEX_OF_THE_PIN_KEY;
    private String RESULT_OF_THE_AUTHENTICATION_OF_THE_OWNER;
    private int MOBILE_ACCEPTANCE_INDICATOR;
    private String NUMBER_DIGITS_OF_TYPED_PIN;
    private String DRAWER_USED_BY_THE_PIN_PAD;




    private static final int MSG0010_FLAG_CONTROL = 8;
    private static final int MSG0010_REST_RESULT_OF_CHIP_ATTEMPT= 9;
    private static final int MSG0010_EXPIRED_CARD = 10;
    private static final int MSG0010_CARD_TYPE_INDICATOR = 11;
    private static final int MSG0010_LBIN= 12;
    private static final int MSG0010_BIN_OF_THE_CARD = 14;
    private static int MSG0010_SERVICE_CODE = 14+LBIN;
    private static int MSG0010_TRACK_ENCRYPTION = 17+LBIN;
    private static int MSG0010_IDENTIFIER_OF_THE_KEY = 18+LBIN;
    private static int MSG0010_LPISTA1 = 19+LBIN;
    private static int MSG0010_READING_TRACK1 = 23+LBIN;
    private static int MSG0010_LPISTA2 = 23+LBIN+LIPSTA1;
    private static int MSG0010_READING_TRACK2 = 27+LBIN+LIPSTA1;
    private static int MSG0010_RANDOM_NUMBER_OF_TRACK_ENCRYPTION = 27+LBIN+LIPSTA1+LIPSTA2;
    private static int MSG0010_ENCRYPTION_PIN_BLOCK = 33+LBIN+LIPSTA1+LIPSTA2;
    private static int MSG0010_ZONE_INDEX_OF_THE_PIN_KEY = 49+LBIN+LIPSTA1+LIPSTA2;
    private static int MSG0010_RESULT_OF_THE_AUTHENTICATION_OF_THE_OWNER = 51+LBIN+LIPSTA1+LIPSTA2;
    private static int MSG0010_MOBILE_ACCEPTANCE_INDICATOR = 63+LBIN+LIPSTA1+LIPSTA2;
    private static int MSG0010_NUMBER_DIGITS_OF_TYPED_PIN = 65+LBIN+LIPSTA1+LIPSTA2;
    private static int MSG0010_DRAWER_USED_BY_THE_PIN_PAD = 66+LBIN+LIPSTA1+LIPSTA2;
    private static int MSG0010_PROPRIETARY_DATA_LENGTH_OFF = 69+LBIN+LIPSTA1+LIPSTA2;







    private static final int MSG0010_FLAG_CONTROL_SIZE = 1;
    private static final int MSG0010_LAST_RESULT_OF_CHIP_ATTEMPT_SIZE = 1;
    private static final int MSG0010_EXPIRED_CARD_SIZE = 1;
    private static final int MSG0010_CARD_TYPE_INDICATOR_SIZE = 1;
    private static final int MSG0010_LBIN_SIZE = 2;
    private static int MSG0010_BIN_OF_THE_CARD_SIZE = LBIN;
    private static final int MSG0010_SERVICE_CODE_SIZE = 3;
    private static final int MSG0010_TRACK_ENCRYPTION_SIZE = 1;
    private static final int MSG0010_IDENTIFIER_OF_THE_KEY_SIZE = 1;
    private static final int MSG0010_LPISTA1_SIZE = 4;
    private static int MSG0010_READING_TRACK1_SIZE = LIPSTA1;
    private static final int MSG0010_LPISTA2_SIZE = 4;
    private static int MSG0010_READING_TRACK2_SIZE = LIPSTA2;
    private static final int MSG0010_RANDOM_NUMBER_OF_TRACK_ENCRYPTION_SIZE = 6;
    private static final int MSG0010_ENCRYPTION_PIN_BLOCK_SIZE = 16;
    private static final int MSG0010_ZONE_INDEX_OF_THE_PIN_KEY_SIZE = 2;
    private static final int MSG0010_RESULT_OF_THE_AUTHENTICATION_OF_THE_OWNER_SIZE = 12;
    private static final int MSG0010_MOBILE_ACCEPTANCE_INDICATOR_SIZE = 2;
    private static final int MSG0010_NUMBER_DIGITS_OF_TYPED_PIN_SIZE = 1;
    private static final int MSG0010_DRAWER_USED_BY_THE_PIN_PAD_SIZE = 2;


    public Msg0010(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        FLAG_CONTROL = (short) Integer.parseInt(new String(data, MSG0010_FLAG_CONTROL, MSG0010_FLAG_CONTROL_SIZE));
        REST_RESULT_OF_CHIP_ATTEMPT = (short) Integer.parseInt(new String(data, MSG0010_REST_RESULT_OF_CHIP_ATTEMPT, MSG0010_LAST_RESULT_OF_CHIP_ATTEMPT_SIZE));
        EXPIRED_CARD = (short) Integer.parseInt(new String(data, MSG0010_EXPIRED_CARD, MSG0010_EXPIRED_CARD_SIZE));
        CARD_TYPE_INDICATOR = (short) Integer.parseInt(new String(data, MSG0010_CARD_TYPE_INDICATOR, MSG0010_CARD_TYPE_INDICATOR_SIZE));
        LBIN = Integer.parseInt(new String(data, MSG0010_LBIN, MSG0010_LBIN_SIZE));
        MSG0010_BIN_OF_THE_CARD_SIZE = LBIN;
        BIN_OF_THE_CARD = Integer.parseInt(new String(data, MSG0010_BIN_OF_THE_CARD, MSG0010_BIN_OF_THE_CARD_SIZE));
        MSG0010_SERVICE_CODE = 14+LBIN;
        SERVICE_CODE = Integer.parseInt(new String(data, MSG0010_SERVICE_CODE, MSG0010_SERVICE_CODE_SIZE));
        MSG0010_TRACK_ENCRYPTION = 17+LBIN;
        TRACK_ENCRYPTION = (short) Integer.parseInt(new String(data, MSG0010_TRACK_ENCRYPTION, MSG0010_TRACK_ENCRYPTION_SIZE));
        MSG0010_IDENTIFIER_OF_THE_KEY = 18+LBIN;
        IDENTIFIER_OF_THE_KEY = (short) Integer.parseInt(new String(data, MSG0010_IDENTIFIER_OF_THE_KEY, MSG0010_IDENTIFIER_OF_THE_KEY_SIZE));
        MSG0010_LPISTA1 = 19+LBIN;
        LIPSTA1 = Integer.parseInt(new String(data, MSG0010_LPISTA1, MSG0010_LPISTA1_SIZE));
        MSG0010_READING_TRACK1 = 23+LBIN;
        MSG0010_READING_TRACK1_SIZE = LIPSTA1;
        READING_TRACK1 = String.valueOf(new String(data, MSG0010_READING_TRACK1, MSG0010_READING_TRACK1_SIZE));
        MSG0010_LPISTA2 = 23+LBIN+LIPSTA1;
        LIPSTA2 = Integer.parseInt(new String(data, MSG0010_LPISTA2, MSG0010_LPISTA2_SIZE));
        MSG0010_READING_TRACK2 = 27+LBIN+LIPSTA1;
        MSG0010_READING_TRACK2_SIZE = LIPSTA2;
        READING_TRACK2 = String.valueOf(new String(data, MSG0010_READING_TRACK2, MSG0010_READING_TRACK2_SIZE));
        MSG0010_RANDOM_NUMBER_OF_TRACK_ENCRYPTION = 27+LBIN+LIPSTA1+LIPSTA2;
        RANDOM_NUMBER_OF_TRACK_ENCRYPTION = String.valueOf(new String(data, MSG0010_RANDOM_NUMBER_OF_TRACK_ENCRYPTION, MSG0010_RANDOM_NUMBER_OF_TRACK_ENCRYPTION_SIZE));
        MSG0010_ENCRYPTION_PIN_BLOCK = 33+LBIN+LIPSTA1+LIPSTA2;
        ENCRYPTION_PIN_BLOCK = Integer.parseInt(new String(data, MSG0010_ENCRYPTION_PIN_BLOCK, MSG0010_ENCRYPTION_PIN_BLOCK_SIZE));
        MSG0010_ZONE_INDEX_OF_THE_PIN_KEY = 49+LBIN+LIPSTA1+LIPSTA2;
        ZONE_INDEX_OF_THE_PIN_KEY = Integer.parseInt(new String(data, MSG0010_ZONE_INDEX_OF_THE_PIN_KEY, MSG0010_ZONE_INDEX_OF_THE_PIN_KEY_SIZE));
        MSG0010_RESULT_OF_THE_AUTHENTICATION_OF_THE_OWNER = 51+LBIN+LIPSTA1+LIPSTA2;
        RESULT_OF_THE_AUTHENTICATION_OF_THE_OWNER = String.valueOf(new String(data, MSG0010_RESULT_OF_THE_AUTHENTICATION_OF_THE_OWNER, MSG0010_RESULT_OF_THE_AUTHENTICATION_OF_THE_OWNER_SIZE));
        MSG0010_MOBILE_ACCEPTANCE_INDICATOR = 63+LBIN+LIPSTA1+LIPSTA2;
        MOBILE_ACCEPTANCE_INDICATOR = Integer.parseInt(new String(data, MSG0010_MOBILE_ACCEPTANCE_INDICATOR, MSG0010_MOBILE_ACCEPTANCE_INDICATOR_SIZE));
        MSG0010_NUMBER_DIGITS_OF_TYPED_PIN = 65+LBIN+LIPSTA1+LIPSTA2;
        NUMBER_DIGITS_OF_TYPED_PIN =(new String(data, MSG0010_NUMBER_DIGITS_OF_TYPED_PIN, MSG0010_NUMBER_DIGITS_OF_TYPED_PIN_SIZE));
        MSG0010_DRAWER_USED_BY_THE_PIN_PAD = 66+LBIN+LIPSTA1+LIPSTA2;
        DRAWER_USED_BY_THE_PIN_PAD = String.valueOf(new String(data, MSG0010_DRAWER_USED_BY_THE_PIN_PAD, MSG0010_DRAWER_USED_BY_THE_PIN_PAD_SIZE));
        MSG0010_PROPRIETARY_DATA_LENGTH_OFF = 69+LBIN+LIPSTA1+LIPSTA2;
        setProprietaryData(data, MSG0010_PROPRIETARY_DATA_LENGTH_OFF);
    }

}
