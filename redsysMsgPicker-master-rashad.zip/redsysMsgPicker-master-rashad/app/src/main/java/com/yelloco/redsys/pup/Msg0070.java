package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;

public class Msg0070 extends Msg {


    public static final String ID = "0070";

    private static final int MSG0070_STATE = 8;
    private static final int MSG0070_ZONE_INDEX_OF_THE_PIN_KEY= 14;
    private static final int MSG0070_NUMBER_DIGITS_OF_TYPE_PIN = 16;
    private static final int MSG0070_DRAWER_USED_BY_THE_PIN_PAD= 17;

    private static final int MSG0070_SEPARATOR_OFF= 19;
    private static final int MSG0070_PROPRIETARY_DATA_LENGTH_OFF = 20;
    private static final int MSG0070_PROPRIETARY_DATA_OFF = 23;

    private static final int MSG0070_STATE_SIZE = 6;
    private static final int MSG0070_ZONE_INDEX_OF_THE_PIN_KEY_SIZE = 2;
    private static final int MSG0070_NUMBER_DIGITS_OF_TYPE_PIN_SIZE = 1;
    private static final int MSG0070_DRAWER_USED_BY_THE_PIN_PAD_SIZE = 2;


    private int STATE;
    private int zone_index_of_pin_key;
    private String digits_number_pin;
    private String drawer_used;

    public Msg0070(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        STATE = Integer.parseInt(new String(data, MSG0070_STATE, MSG0070_STATE_SIZE));
        zone_index_of_pin_key = Integer.parseInt(new String(data, MSG0070_ZONE_INDEX_OF_THE_PIN_KEY, MSG0070_ZONE_INDEX_OF_THE_PIN_KEY_SIZE));
        digits_number_pin = (new String(data, MSG0070_NUMBER_DIGITS_OF_TYPE_PIN, MSG0070_NUMBER_DIGITS_OF_TYPE_PIN_SIZE));
        drawer_used = (new String(data, MSG0070_DRAWER_USED_BY_THE_PIN_PAD, MSG0070_DRAWER_USED_BY_THE_PIN_PAD_SIZE));
        setProprietaryData(data, MSG0070_PROPRIETARY_DATA_LENGTH_OFF);

    }



}
