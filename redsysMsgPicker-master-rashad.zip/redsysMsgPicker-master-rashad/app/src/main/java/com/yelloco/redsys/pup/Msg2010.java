package com.yelloco.redsys.pup;

import android.util.Log;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;

/**
 * Created by trnguyen on 03/04/18.
 */

public class Msg2010 extends Msg {
    private static final String TAG = Msg2010.class.getSimpleName();
    public static final String ID = "2010";

    private static final int MSG2010_SERIAL_NUMBER_OFF = 8;
    private static final int MSG2010_BUFFER_LENGTH_OFF= 19;
    private static final int MSG2010_PUB_KEY_VER_OFF = 27;
    private static final int MSG2010_SYM_KEY_VER_OFF= 30;
    private static final int MSG2010_PARAMS_VER_OFF = 33;
    private static final int MSG2010_PRODUCER_OFF = 36;
    private static final int MSG2010_MODEL_OFF = 38;
    private static final int MSG2010_FUNCTIONS_OFF = 40;
    private static final int MSG2010_SOFTWARE_NAME_OFF = 44;
    private static final int MSG2010_EMV_VER_OFF = 52;
    private static final int MSG2010_SPEC_VER_OFF = 56;
    private static final int MSG2010_DESK_NB_OFF = 58;

    private static final int MSG2010_SERIAL_NUMBER_SIZE = 11;
    private static final int MSG2010_BUFFER_LENGTH_SIZE = 8;
    private static final int MSG2010_PUB_KEY_VER_SIZE = 3;
    private static final int MSG2010_SYM_KEY_VER_SIZE= 3;
    private static final int MSG2010_PARAMS_VER_SIZE = 3;
    private static final int MSG2010_PRODUCER_SIZE = 2;
    private static final int MSG2010_MODEL_SIZE = 2;
    private static final int MSG2010_FUNCTIONS_SIZE = 4;
    private static final int MSG2010_SOFTWARE_NAME_SIZE = 8;
    private static final int MSG2010_EMV_VER_SIZE = 4;
    private static final int MSG2010_SPEC_VER_SIZE = 2;
    private static final int MSG2010_DESK_NB_SIZE = 2;
    private static final int MSG2010_PCI_SCENARIO_SIZE = 1;

    private String serialNumber;
    private int bufferLength;
    private String publicKeyVersion;
    private String symKeyVersion;
    private String paramVersion;
    private String producer;
    private String model;
    private String functions;
    private String softwareName;
    private String emvVersion;
    private short specVersion;
    private short deskNumber;
    private byte pciScenario;



    public void fillForTesting() {
        setSerialNumber("YelloSerial");
        setBufferLength(MSG_MAX_SIZE);
        setPublicKeyVersion("000");
        setSymKeyVersion("000");
        setParamVersion("000");
        setProducer("Pro");
        setModel("YL7");
        setFunctions("0000");
        setSoftwareName("Software");
        setEmvVersion("1001");
        setSpecVersion((short) 16);
        setDeskNumber((short) 0);
        setPciScenario((byte) '1');
    }

    public byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, MSG2010_SERIAL_NUMBER_OFF, serialNumber.getBytes(), MSG2010_SERIAL_NUMBER_SIZE);
        BufferUtil.put(buffer, MSG2010_BUFFER_LENGTH_OFF, String.format("%08d", bufferLength).getBytes(), MSG2010_BUFFER_LENGTH_SIZE);
        BufferUtil.put(buffer, MSG2010_PUB_KEY_VER_OFF, publicKeyVersion.getBytes(), MSG2010_PUB_KEY_VER_SIZE);
        BufferUtil.put(buffer, MSG2010_SYM_KEY_VER_OFF, symKeyVersion.getBytes(), MSG2010_SYM_KEY_VER_SIZE);
        BufferUtil.put(buffer, MSG2010_PARAMS_VER_OFF, paramVersion.getBytes(), MSG2010_PARAMS_VER_SIZE);
        BufferUtil.put(buffer, MSG2010_PRODUCER_OFF, producer.getBytes(), MSG2010_PRODUCER_SIZE);
        BufferUtil.put(buffer, MSG2010_MODEL_OFF, model.getBytes(), MSG2010_MODEL_SIZE);
        BufferUtil.put(buffer, MSG2010_FUNCTIONS_OFF, functions.getBytes(), MSG2010_FUNCTIONS_SIZE);
        BufferUtil.put(buffer, MSG2010_SOFTWARE_NAME_OFF, softwareName.getBytes(), MSG2010_SOFTWARE_NAME_SIZE);
        BufferUtil.put(buffer, MSG2010_EMV_VER_OFF, emvVersion.getBytes(), MSG2010_EMV_VER_SIZE);
        BufferUtil.put(buffer, MSG2010_SPEC_VER_OFF, String.format("%02d", specVersion).getBytes(), MSG2010_SPEC_VER_SIZE);
        BufferUtil.put(buffer, MSG2010_DESK_NB_OFF, String.format("%02d", deskNumber).getBytes(), MSG2010_DESK_NB_SIZE);
        if (deskNumber > 0) {
            // not happen yet
        }
        buffer.put(pciScenario);

        buffer.put(MSG_SEPARATOR);
        BufferUtil.put(buffer, String.format("%03d", getProprietaryDataLength()).getBytes(), 0, MSG_PROPRIETARY_DATA_LENGTH_SIZE);
        int dataLength = buffer.position();

        // setLength of the buffer
        BufferUtil.put(buffer, MSG_LENGTH_FIELD_OFF, String.format("%04d", dataLength).getBytes());
        setLength(dataLength);

        return data;
    }

    public void printData() {
        ByteBuffer buffer = ByteBuffer.wrap(toPupMessage());

        String value = "";
        value += String.format("id: value:%s hexData:%s\n", ID, BufferUtil.toHexString(buffer, MSG_ID_FIELD_SIZE));
        value += String.format("length: value:%d hexData:%s\n", getLength(), BufferUtil.toHexString(buffer, MSG_LENGTH_FIELD_SIZE));
        value += String.format("serialNumber: value:%s hexData:%s\n", serialNumber, BufferUtil.toHexString(buffer, MSG2010_SERIAL_NUMBER_SIZE));
        value += String.format("bufferLength: value:%d hexData:%s\n", bufferLength, BufferUtil.toHexString(buffer, MSG2010_BUFFER_LENGTH_SIZE));
        value += String.format("publicKeyVersion: value:%s hexData:%s\n", publicKeyVersion, BufferUtil.toHexString(buffer, MSG2010_PUB_KEY_VER_SIZE));
        value += String.format("symKeyVersion: value:%s hexData:%s\n", symKeyVersion, BufferUtil.toHexString(buffer, MSG2010_SYM_KEY_VER_SIZE));
        value += String.format("paramVersion: value:%s hexData:%s\n", paramVersion, BufferUtil.toHexString(buffer, MSG2010_PARAMS_VER_SIZE));
        value += String.format("producer: value:%s hexData:%s\n", producer, BufferUtil.toHexString(buffer, MSG2010_PRODUCER_SIZE));
        value += String.format("model: value:%s hexData:%s\n", model, BufferUtil.toHexString(buffer, MSG2010_MODEL_SIZE));
        value += String.format("functions: value:%s hexData:%s\n", functions, BufferUtil.toHexString(buffer, MSG2010_FUNCTIONS_SIZE));
        value += String.format("softwareName: value:%s hexData:%s\n", softwareName, BufferUtil.toHexString(buffer, MSG2010_SOFTWARE_NAME_SIZE));
        value += String.format("emvVersion: value:%s hexData:%s\n", emvVersion, BufferUtil.toHexString(buffer, MSG2010_EMV_VER_SIZE));
        value += String.format("specVersion: value:%d hexData:%s\n", specVersion, BufferUtil.toHexString(buffer, MSG2010_SPEC_VER_SIZE));
        value += String.format("deskNumber: value:%d hexData:%s\n", deskNumber, BufferUtil.toHexString(buffer, MSG2010_DESK_NB_SIZE));
        value += String.format("pciScenario: value:%s hexData:%s\n", pciScenario, BufferUtil.toHexString(buffer, MSG2010_PCI_SCENARIO_SIZE));
        value += String.format("separator: value:%s hexData:%s\n", MSG_SEPARATOR, BufferUtil.toHexString(buffer, MSG_SEPARATOR_SIZE));
        value += String.format("proprietaryDataLength: value:%d hexData:%s\n", getProprietaryDataLength(), BufferUtil.toHexString(buffer, MSG_PROPRIETARY_DATA_LENGTH_SIZE));

        Log.d(TAG, value);
    }

    public Msg2010 setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
        return this;
    }

    public Msg2010 setBufferLength(int bufferLength) {
        this.bufferLength = bufferLength;
        return this;
    }

    public Msg2010 setPublicKeyVersion(String publicKeyVersion) {
        this.publicKeyVersion = publicKeyVersion;
        return this;
    }

    public Msg2010 setSymKeyVersion(String symKeyVersion) {
        this.symKeyVersion = symKeyVersion;
        return this;
    }

    public Msg2010 setParamVersion(String paramVersion) {
        this.paramVersion = paramVersion;
        return this;
    }

    public Msg2010 setProducer(String producer) {
        this.producer = producer;
        return this;
    }

    public Msg2010 setModel(String model) {
        this.model = model;
        return this;
    }

    public Msg2010 setFunctions(String functions) {
        this.functions = functions;
        return this;
    }

    public Msg2010 setSoftwareName(String softwareName) {
        this.softwareName = softwareName;
        return this;
    }

    public Msg2010 setEmvVersion(String emvVersion) {
        this.emvVersion = emvVersion;
        return this;
    }

    public Msg2010 setSpecVersion(short specVersion) {
        this.specVersion = specVersion;
        return this;
    }

    public Msg2010 setDeskNumber(short deskNumber) {
        this.deskNumber = deskNumber;
        return this;
    }

    public Msg2010 setPciScenario(byte pciScenario) {
        this.pciScenario = pciScenario;
        return this;
    }

}
