package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;

public class Msg4002 extends Msg {

    public static final String ID = "4002";
    private short total_num_blocks;
    private short block_num;
    private static int length_of_pro_data=0;
    private String pro_data;

    private static final int MSG4002_TOTAL_NUM_OF_BLOCKS = 8;
    private static final int MSG4002_BLOCK_NUM= 11;
    private static final int MSG4002_LENGTH_OF_PRO_DATA = 14;
    private static final int MSG4002_PRO_DATA= 22;

    private static final int MSG4002_SEPARATOR_OFF= 22+length_of_pro_data;
    private static int MSG4002_PROPRIETARY_DATA_LENGTH_OFF = 23+length_of_pro_data;
    private static final int MSG4002_PROPRIETARY_DATA_OFF = 26+length_of_pro_data;

    private static final int MSG4002_TOTAL_NUM_OF_BLOCKS_SIZE = 3;
    private static final int MSG4002_BLOCK_NUM_SIZE = 3;
    private static final int MSG4002_LENGTH_OF_PRO_DATA_SIZE = 8;
    private static int MSG4002_PRO_DATA_SIZE = length_of_pro_data;




    public Msg4002(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        total_num_blocks = (short) Integer.parseInt(new String(data, MSG4002_TOTAL_NUM_OF_BLOCKS, MSG4002_TOTAL_NUM_OF_BLOCKS_SIZE));
        block_num = (short) Integer.parseInt(new String(data, MSG4002_BLOCK_NUM, MSG4002_BLOCK_NUM_SIZE));
        length_of_pro_data = Integer.parseInt(new String(data, MSG4002_LENGTH_OF_PRO_DATA, MSG4002_LENGTH_OF_PRO_DATA_SIZE));
        MSG4002_PRO_DATA_SIZE = length_of_pro_data;
        pro_data = (new String(data, MSG4002_PRO_DATA, MSG4002_PRO_DATA_SIZE));
        MSG4002_PROPRIETARY_DATA_LENGTH_OFF = 23+length_of_pro_data;
        setProprietaryData(data, MSG4002_PROPRIETARY_DATA_LENGTH_OFF);

    }



}
