package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;

public class Msg0100 extends Msg {

    public static final String ID = "0100";




    private short CONTACTLESS_INDICATOR;
    private static int LBIN=0;
    private int BIN_OF_THE_CARD;
    private int SERVICE_CODE;
    private short TRACK_ENCRYPTION;
    private short IDENTIFIER_OF_THE_KEY;
    private static int LPETA=0;
    private String REQUEST_FOR_AUTHORIZATION;
    private int ESTADO;
    private String TERMINAL_ACTION_CODE;
    private String RANDOM_NUMBER_OF_TRACK_ENCRYPTION;
    private String ENCRYPTION_PIN_BLOCK;
    private short ZONE_INDEX_OF_THE_PIN_KEY;
    private String NUMBER_DIGITS_OF_TYPED_PIN;
    private String DRAWER_USED_BY_THE_PIN_PAD;








    private static final int MSG0100_CONTACTLESS_INDICATOR = 8;
    private static final int MSG0100_LBIN= 9;
    private static final int MSG0100_BIN_OF_THE_CARD = 11;
    private static int MSG0100_SERVICE_CODE = 11+LBIN;
    private static int MSG0100_TRACK_ENCRYPTION = 14+LBIN;
    private static int MSG0100_IDENTIFIER_OF_THE_KEY = 15+LBIN;
    private static int MSG0100_LPeta = 16+LBIN;
    private static int MSG0100_REQUEST_FOR_AUTHORIZATION = 20+LBIN;
    private static int MSG0100_ESTADO = 20+LBIN+LPETA;
    private static int MSG0100_TERMINAL_ACTION_CODE = 24+LBIN+LPETA;
    private static int MSG0100_RANDOM_NUMBER_OF_TRACK_ENCRYPTION = 54+LBIN+LPETA;
    private static int MSG0100_ENCRYPTION_PIN_BLOCK = 60+LBIN+LPETA;
    private static int MSG0100_ZONE_INDEX_OF_THE_PIN_KEY = 62+LBIN+LPETA;
    private static int MSG0100_NUMBER_DIGITS_OF_TYPED_PIN = 78+LBIN+LPETA;
    private static int MSG0100_DRAWER_USED_BY_THE_PIN_PAD = 79+LBIN+LPETA;
    private static int MSG0100_PROPRIETARY_DATA_LENGTH_OFF = 82+LBIN+LPETA;







    private static final int MSG0100_CONTACTLESS_INDICATOR_SIZE = 1;
    private static final int MSG0100_LBIN_SIZE = 2;
    private static int MSG0100_BIN_OF_THE_CARD_SIZE = LBIN;
    private static final int MSG0100_SERVICE_CODE_SIZE = 3;
    private static final int MSG0100_TRACK_ENCRYPTION_SIZE = 1;
    private static final int MSG0100_IDENTIFIER_OF_THE_KEY_SIZE = 1;
    private static final int MSG0100_LPeta_SIZE = 4;
    private static int MSG0100_MSG0100_REQUEST_FOR_AUTHORIZATION_SIZE = LPETA;
    private static final int MSG0100_MSG0100_ESTADO_SIZE = 4;
    private static final int MSG0100_TERMINAL_ACTION_CODE_SIZE = 30;
    private static final int MSG0100_RANDOM_NUMBER_OF_TRACK_ENCRYPTION_SIZE = 6;
    private static final int MSG0100_ENCRYPTION_PIN_BLOCK_SIZE = 16;
    private static final int MSG0100_ZONE_INDEX_OF_THE_PIN_KEY_SIZE = 2;
    private static final int MSG0100_NUMBER_DIGITS_OF_TYPED_PIN_SIZE = 1;
    private static final int MSG0100_DRAWER_USED_BY_THE_PIN_PAD_SIZE = 2;



    public Msg0100(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        CONTACTLESS_INDICATOR = (short) Integer.parseInt(new String(data, MSG0100_CONTACTLESS_INDICATOR, MSG0100_CONTACTLESS_INDICATOR_SIZE));
        LBIN = Integer.parseInt(new String(data, MSG0100_LBIN, MSG0100_LBIN_SIZE));
        MSG0100_BIN_OF_THE_CARD_SIZE = LBIN;
        BIN_OF_THE_CARD = Integer.parseInt(new String(data, MSG0100_BIN_OF_THE_CARD, MSG0100_BIN_OF_THE_CARD_SIZE));
        MSG0100_SERVICE_CODE = 11+LBIN;
        SERVICE_CODE = Integer.parseInt(new String(data, MSG0100_SERVICE_CODE, MSG0100_SERVICE_CODE_SIZE));
        MSG0100_TRACK_ENCRYPTION = 14+LBIN;
        TRACK_ENCRYPTION = (short) Integer.parseInt(new String(data, MSG0100_TRACK_ENCRYPTION, MSG0100_TRACK_ENCRYPTION_SIZE));
        MSG0100_IDENTIFIER_OF_THE_KEY = 15+LBIN;
        IDENTIFIER_OF_THE_KEY = (short) Integer.parseInt(new String(data, MSG0100_IDENTIFIER_OF_THE_KEY, MSG0100_IDENTIFIER_OF_THE_KEY_SIZE));
        MSG0100_LPeta = 16+LBIN;
        LPETA = Integer.parseInt(new String(data, MSG0100_LPeta, MSG0100_LPeta_SIZE));
        MSG0100_REQUEST_FOR_AUTHORIZATION = 20+LBIN;
        MSG0100_MSG0100_REQUEST_FOR_AUTHORIZATION_SIZE = LPETA;
        REQUEST_FOR_AUTHORIZATION = String.valueOf(new String(data, MSG0100_REQUEST_FOR_AUTHORIZATION, MSG0100_MSG0100_REQUEST_FOR_AUTHORIZATION_SIZE));
        MSG0100_ESTADO = 20+LBIN+LPETA;
        ESTADO = Integer.parseInt(new String(data, MSG0100_ESTADO, MSG0100_MSG0100_ESTADO_SIZE));
        MSG0100_TERMINAL_ACTION_CODE = 24+LBIN+LPETA;
        TERMINAL_ACTION_CODE = String.valueOf(new String(data, MSG0100_TERMINAL_ACTION_CODE, MSG0100_TERMINAL_ACTION_CODE_SIZE));
        MSG0100_RANDOM_NUMBER_OF_TRACK_ENCRYPTION = 54+LBIN+LPETA;
        RANDOM_NUMBER_OF_TRACK_ENCRYPTION = String.valueOf(new String(data, MSG0100_RANDOM_NUMBER_OF_TRACK_ENCRYPTION, MSG0100_RANDOM_NUMBER_OF_TRACK_ENCRYPTION_SIZE));
        MSG0100_ENCRYPTION_PIN_BLOCK = 60+LBIN+LPETA;
        ENCRYPTION_PIN_BLOCK = (new String(data, MSG0100_ENCRYPTION_PIN_BLOCK, MSG0100_ENCRYPTION_PIN_BLOCK_SIZE));
        MSG0100_ZONE_INDEX_OF_THE_PIN_KEY = 62+LBIN+LPETA;
        ZONE_INDEX_OF_THE_PIN_KEY = (short) Integer.parseInt(new String(data, MSG0100_ZONE_INDEX_OF_THE_PIN_KEY, MSG0100_ZONE_INDEX_OF_THE_PIN_KEY_SIZE));
        MSG0100_NUMBER_DIGITS_OF_TYPED_PIN = 78+LBIN+LPETA;
        NUMBER_DIGITS_OF_TYPED_PIN = (new String(data, MSG0100_NUMBER_DIGITS_OF_TYPED_PIN, MSG0100_NUMBER_DIGITS_OF_TYPED_PIN_SIZE));
        MSG0100_DRAWER_USED_BY_THE_PIN_PAD = 79+LBIN+LPETA;
        DRAWER_USED_BY_THE_PIN_PAD = (new String(data, MSG0100_DRAWER_USED_BY_THE_PIN_PAD, MSG0100_DRAWER_USED_BY_THE_PIN_PAD_SIZE));
        MSG0100_PROPRIETARY_DATA_LENGTH_OFF = 82+LBIN+LPETA;
        setProprietaryData(data, MSG0100_PROPRIETARY_DATA_LENGTH_OFF);
    }



}

