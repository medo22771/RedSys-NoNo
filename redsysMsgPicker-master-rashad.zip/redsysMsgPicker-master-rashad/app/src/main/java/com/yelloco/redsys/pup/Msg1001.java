package com.yelloco.redsys.pup;

import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Msg1001 extends Msg {

    public static final String ID = "1001";

    private static final int MSG1001_MESSAGE_IDENTIFIER = 8;
    private static final int MSG1001_AMOUNT_OF_TRANSACTION= 12;
    private static final int MSG1001_TABLE_FOR_RISK_CONTROL = 22;
    private static final int MSG1001_SEPARATOR_OFF= 24;
    private static final int MSG1001_PROPRIETARY_DATA_LENGTH_OFF = 25;
    private static final int MSG1001_PROPRIETARY_DATA_OFF = 28;

    private static final int MSG1001_MESSAGE_IDENTIFIER_SIZE = 4;
    private static final int MSG1001_AMOUNT_OF_TRANSACTION_SIZE = 10;
    private static final int MSG1001_TABLE_FOR_RISK_CONTROL_SIZE = 2;


    private int message_identifier;
    private int transaction_amount;
    private String risk_control_table;

    public Msg1001(byte[] data, int length) {
        super(data, length);
        fromPupMessage(data);
    }

    public void fromPupMessage(byte[] data) {
        ByteBuffer buffer = ByteBuffer.wrap(data);
        message_identifier = Integer.parseInt(new String(data, MSG1001_MESSAGE_IDENTIFIER, MSG1001_MESSAGE_IDENTIFIER_SIZE));
        transaction_amount = Integer.parseInt(new String(data, MSG1001_AMOUNT_OF_TRANSACTION, MSG1001_AMOUNT_OF_TRANSACTION_SIZE));
        risk_control_table = String.valueOf(Integer.parseInt(new String(data, MSG1001_TABLE_FOR_RISK_CONTROL, MSG1001_TABLE_FOR_RISK_CONTROL_SIZE)));
        setProprietaryData(data, MSG1001_PROPRIETARY_DATA_LENGTH_OFF);

    }

    public void setMessage_identifier(int message_identifier) {
        this.message_identifier = message_identifier;
    }

    public void setTransaction_amount(int transaction_amount) {
        this.transaction_amount = transaction_amount;
    }

    public void setRisk_control_table(String risk_control_table) {
        this.risk_control_table = risk_control_table;
    }
}
