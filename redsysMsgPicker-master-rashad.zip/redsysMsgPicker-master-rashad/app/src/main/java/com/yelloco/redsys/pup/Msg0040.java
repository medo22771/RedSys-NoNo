package com.yelloco.redsys.pup;

import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;
import java.util.Calendar;

public class Msg0040 extends Msg {

    public static final String ID = "0040";

    private static int type_of_information;
    private static int signature_length=0;
    private static String scanned_signature;
    private static short deskNumber;
    private static byte pciScenario;

    private static final int MSG0040_TYPE_OF_INFORMATION = 8;
    private static final int MSG0040_SIGNATURE_KENGTH = 12;
    private static final int MSG0040_SCANNED_SIGNATURE = 16;


    private static final int MSG0040_SEPARATOR_OFF= 16+signature_length;
    private static final int MSG0040_PROPRIETARY_DATA_LENGTH_OFF = 17+signature_length;
    private static final int MSG0040_PROPRIETARY_DATA_OFF = 20+signature_length;

    private static final int MSG0040_TYPE_OF_INFORMATION_SIZE = 10;
    private static final int MSG0040_SIGNATURE_KENGTH_SIZE = 2;
    private static int MSG0040_SCANNED_SIGNATURE_SIZE = signature_length;




//    public Msg0040(byte[] data, int length) {
//        super(data, length);
//        fromPupMessage(data);
//    }
//
//    public void fromPupMessage(byte[] data) {
//        ByteBuffer buffer = ByteBuffer.wrap(data);
//        type_of_information = Integer.parseInt(new String(data, MSG0040_TYPE_OF_INFORMATION, MSG0040_TYPE_OF_INFORMATION_SIZE));
//        signature_length = Integer.parseInt(new String(data, MSG0040_SIGNATURE_KENGTH, MSG0040_SIGNATURE_KENGTH_SIZE));
//        scanned_signature = Integer.parseInt(new String(data, MSG0040_SCANNED_SIGNATURE, MSG0040_SCANNED_SIGNATURE_SIZE));
//
//        setProprietaryData(data, MSG0040_PROPRIETARY_DATA_LENGTH_OFF);
//
//    }

    public void fillForTesting() {
        setType_of_information(0001);
        setSignature_length(0001);
        setScanned_signature("0002");

    }



    public static byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, MSG0040_TYPE_OF_INFORMATION, String.format("%04d", type_of_information).getBytes(), MSG0040_TYPE_OF_INFORMATION_SIZE);
        BufferUtil.put(buffer, MSG0040_SIGNATURE_KENGTH, String.format("%04d", signature_length).getBytes(), MSG0040_SIGNATURE_KENGTH_SIZE);
        MSG0040_SCANNED_SIGNATURE_SIZE = signature_length;
        BufferUtil.put(buffer, MSG0040_SCANNED_SIGNATURE, String.format("%04d", scanned_signature).getBytes(), MSG0040_SCANNED_SIGNATURE_SIZE);
        if (deskNumber > 0) {
            // not happen yet
        }
        buffer.put(pciScenario);

        buffer.put(MSG_SEPARATOR);
        BufferUtil.put(buffer, String.format("%03d", getProprietaryDataLength()).getBytes(), 0, MSG_PROPRIETARY_DATA_LENGTH_SIZE);
        int dataLength = buffer.position();

        // setLength of the buffer
        BufferUtil.put(buffer, MSG_LENGTH_FIELD_OFF, String.format("%04d", dataLength).getBytes());
        setLength(dataLength);

        return data;
    }



    public void setType_of_information(int type_of_information) {
        this.type_of_information = type_of_information;
    }

    public static void setSignature_length(int signature_length) {
        Msg0040.signature_length = signature_length;
    }

    public void setScanned_signature(String scanned_signature) {
        this.scanned_signature = scanned_signature;
    }

}
