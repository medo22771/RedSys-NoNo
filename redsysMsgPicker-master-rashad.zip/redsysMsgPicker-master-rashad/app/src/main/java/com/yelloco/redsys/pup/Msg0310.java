package com.yelloco.redsys.pup;

import com.yelloco.redsys.pup.Msg;
import com.yelloco.redsys.util.BufferUtil;

import java.nio.ByteBuffer;

public class Msg0310 extends Msg {


    public static final String ID = "0310";

    private static final int Msg0310_CORRECT_READING_INDICATOR= 8;
    private static final int MSG0310_SEPARATOR_OFF= 12;
    private static final int MSG0310_PROPRIETARY_DATA_LENGTH_OFF = 13;
    private static final int MS0310_PROPRIETARY_DATA_OFF = 16;

    private static final int Msg0310_CORRECT_READING_INDICATOR_SIZE = 4;

    private static int CORRECT_READING_INDICATOR;
    private static short deskNumber;
    private static byte pciScenario;

//    public Msg0310(byte[] data, int length) {
//        super(data, length);
//        fromPupMessage(data);
//    }
//
//    public void fromPupMessage(byte[] data) {
//        CORRECT_READING_INDICATOR = Integer.parseInt(new String(data, Msg0310_CORRECT_READING_INDICATOR, Msg0310_CORRECT_READING_INDICATOR_SIZE));
//        setProprietaryData(data, MSG0310_PROPRIETARY_DATA_LENGTH_OFF);
//    }

    public void setCONFIRMATION_ANSWER(int readingState) {
        CORRECT_READING_INDICATOR = readingState;
    }

    public void fillForTesting() {
        setCorrectReadingIndicator(0003);
    }


    public static byte[] toPupMessage() {
        byte[] data = new byte[MSG_MAX_SIZE];

        ByteBuffer buffer = ByteBuffer.wrap(data);
        BufferUtil.put(buffer, MSG_ID_FIELD_OFF, ID.getBytes(), MSG_ID_FIELD_SIZE);
        BufferUtil.put(buffer, Msg0310_CORRECT_READING_INDICATOR, String.format("%04d", CORRECT_READING_INDICATOR).getBytes(), Msg0310_CORRECT_READING_INDICATOR_SIZE);
        if (deskNumber > 0) {
            // not happen yet
        }
        buffer.put(pciScenario);

        buffer.put(MSG_SEPARATOR);
        BufferUtil.put(buffer, String.format("%03d", getProprietaryDataLength()).getBytes(), 0, MSG_PROPRIETARY_DATA_LENGTH_SIZE);
        int dataLength = buffer.position();

        // setLength of the buffer
        BufferUtil.put(buffer, MSG_LENGTH_FIELD_OFF, String.format("%04d", dataLength).getBytes());
        setLength(dataLength);

        return data;
    }

    public static void setCorrectReadingIndicator(int correctReadingIndicator) {
        CORRECT_READING_INDICATOR = correctReadingIndicator;
    }
}
